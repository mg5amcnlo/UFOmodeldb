# This file was automatically created by FeynRules 2.3.36
# Mathematica version: 11.0.0 for Linux x86 (64-bit) (July 28, 2016)
# Date: Wed 15 Jul 2020 15:56:26


from object_library import all_lorentz, Lorentz

from function_library import complexconjugate, re, im, csc, sec, acsc, asec, cot
try:
   import form_factors as ForFac 
except ImportError:
   pass


UUS2 = Lorentz(name = 'UUS2',
               spins = [ -1, -1, 1 ],
               structure = '1')

UUV2 = Lorentz(name = 'UUV2',
               spins = [ -1, -1, 3 ],
               structure = 'P(3,2) + P(3,3)')

SSS2 = Lorentz(name = 'SSS2',
               spins = [ 1, 1, 1 ],
               structure = '1')

FFS5 = Lorentz(name = 'FFS5',
               spins = [ 2, 2, 1 ],
               structure = 'ProjM(2,1)')

FFS6 = Lorentz(name = 'FFS6',
               spins = [ 2, 2, 1 ],
               structure = 'ProjM(2,1) - ProjP(2,1)')

FFS7 = Lorentz(name = 'FFS7',
               spins = [ 2, 2, 1 ],
               structure = 'ProjP(2,1)')

FFS8 = Lorentz(name = 'FFS8',
               spins = [ 2, 2, 1 ],
               structure = 'ProjM(2,1) + ProjP(2,1)')

FFV6 = Lorentz(name = 'FFV6',
               spins = [ 2, 2, 3 ],
               structure = 'Gamma(3,2,1)')

FFV7 = Lorentz(name = 'FFV7',
               spins = [ 2, 2, 3 ],
               structure = 'Gamma(3,2,-1)*ProjM(-1,1)')

FFV8 = Lorentz(name = 'FFV8',
               spins = [ 2, 2, 3 ],
               structure = 'Gamma(3,2,-1)*ProjM(-1,1) - 2*Gamma(3,2,-1)*ProjP(-1,1)')

FFV9 = Lorentz(name = 'FFV9',
               spins = [ 2, 2, 3 ],
               structure = 'Gamma(3,2,-1)*ProjM(-1,1) + 2*Gamma(3,2,-1)*ProjP(-1,1)')

FFV10 = Lorentz(name = 'FFV10',
                spins = [ 2, 2, 3 ],
                structure = 'Gamma(3,2,-1)*ProjM(-1,1) + 4*Gamma(3,2,-1)*ProjP(-1,1)')

VSS2 = Lorentz(name = 'VSS2',
               spins = [ 3, 1, 1 ],
               structure = 'P(1,2) - P(1,3)')

VVS2 = Lorentz(name = 'VVS2',
               spins = [ 3, 3, 1 ],
               structure = 'Metric(1,2)')

VVV2 = Lorentz(name = 'VVV2',
               spins = [ 3, 3, 3 ],
               structure = 'P(3,1)*Metric(1,2) - P(3,2)*Metric(1,2) - P(2,1)*Metric(1,3) + P(2,3)*Metric(1,3) + P(1,2)*Metric(2,3) - P(1,3)*Metric(2,3)')

SSSS2 = Lorentz(name = 'SSSS2',
                spins = [ 1, 1, 1, 1 ],
                structure = '1')

FFVV7 = Lorentz(name = 'FFVV7',
                spins = [ 2, 2, 3, 3 ],
                structure = '-(Epsilon(3,4,-1,-2)*P(-2,4)*P(-1,3)*Identity(2,1)) + Epsilon(3,4,-1,-2)*P(-2,3)*P(-1,4)*Identity(2,1)')

FFVV8 = Lorentz(name = 'FFVV8',
                spins = [ 2, 2, 3, 3 ],
                structure = 'P(-1,3)*P(3,4)*P(4,1)*Gamma(-1,2,1) + P(-1,4)*P(3,1)*P(4,3)*Gamma(-1,2,1) - P(-1,3)*P(-1,4)*P(4,1)*Gamma(3,2,1) + P(-1,1)*P(-1,4)*P(4,3)*Gamma(3,2,1) - P(-1,3)*P(-1,4)*P(3,1)*Gamma(4,2,1) + P(-1,1)*P(-1,3)*P(3,4)*Gamma(4,2,1) - P(-2,1)*P(-2,4)*P(-1,3)*Gamma(-1,2,1)*Metric(3,4) - P(-2,1)*P(-2,3)*P(-1,4)*Gamma(-1,2,1)*Metric(3,4)')

FFVV9 = Lorentz(name = 'FFVV9',
                spins = [ 2, 2, 3, 3 ],
                structure = 'P(3,4)*P(4,3)*Identity(2,1) - P(-1,3)*P(-1,4)*Identity(2,1)*Metric(3,4)')

FFVV10 = Lorentz(name = 'FFVV10',
                 spins = [ 2, 2, 3, 3 ],
                 structure = '-(Epsilon(3,4,-1,-2)*P(-2,4)*P(-1,3)*ProjM(2,1)) + Epsilon(3,4,-1,-2)*P(-2,3)*P(-1,4)*ProjM(2,1) + Epsilon(3,4,-1,-2)*P(-2,4)*P(-1,3)*ProjP(2,1) - Epsilon(3,4,-1,-2)*P(-2,3)*P(-1,4)*ProjP(2,1)')

FFVV11 = Lorentz(name = 'FFVV11',
                 spins = [ 2, 2, 3, 3 ],
                 structure = 'P(3,4)*P(4,3)*ProjM(2,1) - P(-1,3)*P(-1,4)*Metric(3,4)*ProjM(2,1) - P(3,4)*P(4,3)*ProjP(2,1) + P(-1,3)*P(-1,4)*Metric(3,4)*ProjP(2,1)')

FFVV12 = Lorentz(name = 'FFVV12',
                 spins = [ 2, 2, 3, 3 ],
                 structure = '-(P(-2,1)*P(-2,4)*P(-1,3)*Gamma(-1,2,-3)*Metric(3,4)*ProjM(-3,1)) - P(-2,1)*P(-2,3)*P(-1,4)*Gamma(-1,2,-3)*Metric(3,4)*ProjM(-3,1) + P(-1,3)*P(3,4)*P(4,1)*Gamma(-1,2,-2)*ProjM(-2,1) + P(-1,4)*P(3,1)*P(4,3)*Gamma(-1,2,-2)*ProjM(-2,1) - P(-1,3)*P(-1,4)*P(4,1)*Gamma(3,2,-2)*ProjM(-2,1) + P(-1,1)*P(-1,4)*P(4,3)*Gamma(3,2,-2)*ProjM(-2,1) - P(-1,3)*P(-1,4)*P(3,1)*Gamma(4,2,-2)*ProjM(-2,1) + P(-1,1)*P(-1,3)*P(3,4)*Gamma(4,2,-2)*ProjM(-2,1) + P(-2,1)*P(-2,4)*P(-1,3)*Gamma(-1,2,-3)*Metric(3,4)*ProjP(-3,1) + P(-2,1)*P(-2,3)*P(-1,4)*Gamma(-1,2,-3)*Metric(3,4)*ProjP(-3,1) - P(-1,3)*P(3,4)*P(4,1)*Gamma(-1,2,-2)*ProjP(-2,1) - P(-1,4)*P(3,1)*P(4,3)*Gamma(-1,2,-2)*ProjP(-2,1) + P(-1,3)*P(-1,4)*P(4,1)*Gamma(3,2,-2)*ProjP(-2,1) - P(-1,1)*P(-1,4)*P(4,3)*Gamma(3,2,-2)*ProjP(-2,1) + P(-1,3)*P(-1,4)*P(3,1)*Gamma(4,2,-2)*ProjP(-2,1) - P(-1,1)*P(-1,3)*P(3,4)*Gamma(4,2,-2)*ProjP(-2,1)')

VVSS2 = Lorentz(name = 'VVSS2',
                spins = [ 3, 3, 1, 1 ],
                structure = 'Metric(1,2)')

VVVV6 = Lorentz(name = 'VVVV6',
                spins = [ 3, 3, 3, 3 ],
                structure = 'Metric(1,4)*Metric(2,3) - Metric(1,3)*Metric(2,4)')

VVVV7 = Lorentz(name = 'VVVV7',
                spins = [ 3, 3, 3, 3 ],
                structure = 'Metric(1,4)*Metric(2,3) + Metric(1,3)*Metric(2,4) - 2*Metric(1,2)*Metric(3,4)')

VVVV8 = Lorentz(name = 'VVVV8',
                spins = [ 3, 3, 3, 3 ],
                structure = 'Metric(1,4)*Metric(2,3) - Metric(1,2)*Metric(3,4)')

VVVV9 = Lorentz(name = 'VVVV9',
                spins = [ 3, 3, 3, 3 ],
                structure = 'Metric(1,3)*Metric(2,4) - Metric(1,2)*Metric(3,4)')

VVVV10 = Lorentz(name = 'VVVV10',
                 spins = [ 3, 3, 3, 3 ],
                 structure = 'Metric(1,4)*Metric(2,3) - (Metric(1,3)*Metric(2,4))/2. - (Metric(1,2)*Metric(3,4))/2.')

FFVVV3 = Lorentz(name = 'FFVVV3',
                 spins = [ 2, 2, 3, 3, 3 ],
                 structure = 'P(4,3)*P(5,4)*Gamma(3,2,1) + P(3,4)*P(5,3)*Gamma(4,2,1) - P(-1,4)*P(5,3)*Gamma(-1,2,1)*Metric(3,4) - P(-1,3)*P(5,4)*Gamma(-1,2,1)*Metric(3,4) + P(-1,4)*P(4,3)*Gamma(-1,2,1)*Metric(3,5) - P(-1,3)*P(-1,4)*Gamma(4,2,1)*Metric(3,5) + P(-1,3)*P(3,4)*Gamma(-1,2,1)*Metric(4,5) - P(-1,3)*P(-1,4)*Gamma(3,2,1)*Metric(4,5)')

FFVVV4 = Lorentz(name = 'FFVVV4',
                 spins = [ 2, 2, 3, 3, 3 ],
                 structure = '-(P(-1,4)*P(5,3)*Gamma(-1,2,-2)*Metric(3,4)*ProjM(-2,1)) - P(-1,3)*P(5,4)*Gamma(-1,2,-2)*Metric(3,4)*ProjM(-2,1) + P(-1,4)*P(4,3)*Gamma(-1,2,-2)*Metric(3,5)*ProjM(-2,1) - P(-1,3)*P(-1,4)*Gamma(4,2,-2)*Metric(3,5)*ProjM(-2,1) + P(-1,3)*P(3,4)*Gamma(-1,2,-2)*Metric(4,5)*ProjM(-2,1) - P(-1,3)*P(-1,4)*Gamma(3,2,-2)*Metric(4,5)*ProjM(-2,1) + P(4,3)*P(5,4)*Gamma(3,2,-1)*ProjM(-1,1) + P(3,4)*P(5,3)*Gamma(4,2,-1)*ProjM(-1,1) + P(-1,4)*P(5,3)*Gamma(-1,2,-2)*Metric(3,4)*ProjP(-2,1) + P(-1,3)*P(5,4)*Gamma(-1,2,-2)*Metric(3,4)*ProjP(-2,1) - P(-1,4)*P(4,3)*Gamma(-1,2,-2)*Metric(3,5)*ProjP(-2,1) + P(-1,3)*P(-1,4)*Gamma(4,2,-2)*Metric(3,5)*ProjP(-2,1) - P(-1,3)*P(3,4)*Gamma(-1,2,-2)*Metric(4,5)*ProjP(-2,1) + P(-1,3)*P(-1,4)*Gamma(3,2,-2)*Metric(4,5)*ProjP(-2,1) - P(4,3)*P(5,4)*Gamma(3,2,-1)*ProjP(-1,1) - P(3,4)*P(5,3)*Gamma(4,2,-1)*ProjP(-1,1)')

