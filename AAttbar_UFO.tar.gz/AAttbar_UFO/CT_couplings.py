# This file was automatically created by FeynRules 2.3.36
# Mathematica version: 11.0.0 for Linux x86 (64-bit) (July 28, 2016)
# Date: Wed 15 Jul 2020 15:56:26


from object_library import all_couplings, Coupling

from function_library import complexconjugate, re, im, csc, sec, acsc, asec, cot



