import particles
import couplings
import lorentz
import parameters
import vertices
import coupling_orders
import function_library
import object_library
#from . import write_param_card
try:
    import decays
except ImportError:
    pass    
try:
    from . import build_restrict
except ImportError:
    pass

# model options
gauge = [0, 1]


all_particles = particles.all_particles
all_vertices = vertices.all_vertices
all_couplings = couplings.all_couplings
all_lorentz = lorentz.all_lorentz
all_parameters = parameters.all_parameters
all_orders = coupling_orders.all_orders
all_functions = function_library.all_functions
#all_decays = decays.all_decays
dual_mass_scheme = True


__author__ = "L. Maxia, L. Simon"
__version__ = "2.0"
__email__ = "maxia@lpthe.jussieu.fr, lsimon@lphte.jussieu.fr"
__header__ = \
"""------------------------------------------------------------------------
By loading this model the calculation can involve quarkonia or leptonia.
Please cite refs. 'arXiv:2510.26773' and 'arXiv:2607.26739' when using
results from this code.
------------------------------------------------------------------------
"""
