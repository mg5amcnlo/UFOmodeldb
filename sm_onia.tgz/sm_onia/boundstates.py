from importlib import reload
import object_library
reload(object_library)
from object_library import all_boundstates, Boundstate


#=======================================================================
#  Charmonia
#=======================================================================

#-----------------------------------------------------------------------
#  etac(1S)
#-----------------------------------------------------------------------
etac_11s01 = Boundstate(
    pdg_code = 441,
    name = 'etac(1|1S01)',
    particles = ['c','c~'],
    mass = 2.98,
    principal = 1,
    spin = 1,
    orbital = 0,
    J = 0,
    color = 1,
    charge = 0,
    ldme = 0.3867,
    texname = 'etac11S01'
)

etac_11s08 = Boundstate(
    pdg_code = 9941001,
    name = 'etac(1|1S08)',
    particles = ['c','c~'],
    mass = 3.18,
    principal = 1,
    spin = 1,
    orbital = 0,
    J = 0,
    color = 8,
    charge = 0,
    ldme = 0.00301,
    texname = 'etac11S08'
)

etac_13s18 = Boundstate(
    pdg_code = 9940001,
    name = 'etac(1|3S18)',
    particles = ['c','c~'],
    mass = 3.18,
    principal = 1,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 8,
    charge = 0,
    ldme = 0.0146,
    texname = 'etac13S18'
)

etac_11p18 = Boundstate(
    pdg_code = 9946001,
    name = 'etac(1|1P18)',
    particles = ['c','c~'],
    mass = 3.18,
    principal = 1,
    spin = 1,
    orbital = 1,
    J = 1,
    color = 8,
    charge = 0,
    ldme = 0.1029,
    texname = 'etac11P18'
)

#-----------------------------------------------------------------------
#  etac(2S)
#-----------------------------------------------------------------------
etac_21s01 = Boundstate(
    pdg_code = 100441,
    name = 'etac(2|1S01)',
    particles = ['c','c~'],
    mass = 3.64,
    principal = 2,
    spin = 1,
    orbital = 0,
    J = 0,
    color = 1,
    charge = 0,
    ldme = 0.2526,
    texname = 'etac21S01'
)

etac_21s08 = Boundstate(
    pdg_code = 9941101,
    name = 'etac(2|1S08)',
    particles = ['c','c~'],
    mass = 3.84,
    principal = 2,
    spin = 1,
    orbital = 0,
    J = 0,
    color = 8,
    charge = 0,
    ldme = 0.00116582,
    texname = 'etac21S08'
)

etac_23s18 = Boundstate(
    pdg_code = 9940101,
    name = 'etac(2|3S18)',
    particles = ['c','c~'],
    mass = 3.84,
    principal = 2,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 8,
    charge = 0,
    ldme = 0.00396029,
    texname = 'etac23S18'
)

etac_21p18 = Boundstate(
    pdg_code = 9946101,
    name = 'etac(2|1P18)',
    particles = ['c','c~'],
    mass = 3.84,
    principal = 2,
    spin = 1,
    orbital = 1,
    J = 1,
    color = 8,
    charge = 0,
    ldme = 0.026667,
    texname = 'etac21P18'
)

#-----------------------------------------------------------------------
#  psi(1S)
#-----------------------------------------------------------------------
psi_13s11 = Boundstate(
    pdg_code = 443,
    name = 'Jpsi(1|3S11)',
    particles = ['c','c~'],
    mass = 3.1,
    principal = 1,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 1,
    charge = 0,
    ldme = 1.16,
    texname = 'jpsi13S11'
)

psi_11s08 = Boundstate(
    pdg_code = 9941003,
    name = 'Jpsi(1|1S08)',
    mass = 3.3,
    particles = ['c','c~'],
    principal = 1,
    spin = 1,
    orbital = 0,
    J = 0,
    color = 8,
    charge = 0,
    ldme = 0.0146,
    texname = 'jpsi11S08'
)

psi_13s18 = Boundstate(
    pdg_code = 9940003,
    name = 'Jpsi(1|3S18)',
    mass = 3.3,
    particles = ['c','c~'],
    principal = 1,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 8,
    charge = 0,
    ldme = 0.00903,
    texname = 'jpsi13S18'
)

psi_13p08 = Boundstate(
    pdg_code = 9943003,
    name = 'Jpsi(1|3P08)',
    mass = 3.3,
    particles = ['c','c~'],
    principal = 1,
    spin = 3,
    orbital = 1,
    J = 0,
    color = 8,
    charge = 0,
    ldme = 0.0343,
    texname = 'jpsi13P08'
)

psi_13p18 = Boundstate(
    pdg_code = 9944003,
    name = 'Jpsi(1|3P18)',
    mass = 3.3,
    particles = ['c','c~'],
    principal = 1,
    spin = 3,
    orbital = 1,
    J = 1,
    color = 8,
    charge = 0,
    ldme = 0.1029,
    texname = 'jpsi13P18'
)

psi_13p28 = Boundstate(
    pdg_code = 9945003,
    name = 'Jpsi(1|3P28)',
    mass = 3.3,
    particles = ['c','c~'],
    principal = 1,
    spin = 3,
    orbital = 1,
    J = 2,
    color = 8,
    charge = 0,
    ldme = 0.1715,
    texname = 'jpsi13P28'
)

#-----------------------------------------------------------------------
#  psi(2S)
#-----------------------------------------------------------------------
psi_23s11 = Boundstate(
    pdg_code = 100443,
    name = 'psi(2|3S11)',
    particles = ['c','c~'],
    mass = 3.69,
    principal = 2,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 1,
    charge = 0,
    ldme = 0.7577,
    texname = 'psi23S11'
)

psi_21s08 = Boundstate(
    pdg_code = 9941103,
    name = 'psi(2|1S08)',
    particles = ['c','c~'],
    mass = 3.89,
    principal = 2,
    spin = 1,
    orbital = 0,
    J = 0,
    color = 8,
    charge = 0,
    ldme = 0.00396029,
    texname = 'psi21S08'
)

psi_23s18 = Boundstate(
    pdg_code = 9940103,
    name = 'psi(2|3S18)',
    particles = ['c','c~'],
    mass = 3.89,
    principal = 2,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 8,
    charge = 0,
    ldme = 0.00349746,
    texname = 'psi23S18'
)

psi_23p08 = Boundstate(
    pdg_code = 9943103,
    name = 'psi(2|3P08)',
    mass = 3.89,
    particles = ['c','c~'],
    principal = 2,
    spin = 3,
    orbital = 1,
    J = 0,
    color = 8,
    charge = 0,
    ldme = 0.0088889,
    texname = 'psi23P08'
)

psi_23p18 = Boundstate(
    pdg_code = 9944103,
    name = 'psi(2|3P18)',
    mass = 3.89,
    particles = ['c','c~'],
    principal = 2,
    spin = 3,
    orbital = 1,
    J = 1,
    color = 8,
    charge = 0,
    ldme = 0.026667,
    texname = 'psi23P18'
)

psi_23p28 = Boundstate(
    pdg_code = 9945103,
    name = 'psi(2|3P28)',
    mass = 3.89,
    particles = ['c','c~'],
    principal = 2,
    spin = 3,
    orbital = 1,
    J = 2,
    color = 8,
    charge = 0,
    ldme = 0.044444,
    texname = 'psi23P28'
)

#-----------------------------------------------------------------------
#  hc(1P)
#-----------------------------------------------------------------------
hc_11p11 = Boundstate(
    pdg_code = 10443,
    name = 'hc(1|1P11)',
    particles = ['c','c~'],
    mass = 3.53,
    principal = 1,
    spin = 1,
    orbital = 1,
    J = 1,
    color = 1,
    charge = 0,
    ldme = 0.3223,
    texname = 'hc11P11'
)

hc_11s08 = Boundstate(
    pdg_code = 9941013,
    name = 'hc(1|1S08)',
    particles = ['c','c~'],
    mass = 3.73,
    principal = 1,
    spin = 1,
    orbital = 0,
    J = 0,
    color = 8,
    charge = 0,
    ldme = 0.00645,
    texname = 'hc11S08'
)

#-----------------------------------------------------------------------
#  chic(1P)
#-----------------------------------------------------------------------
chic0_13p01 = Boundstate(
    pdg_code = 10441,
    name = 'chic0(1|3P01)',
    particles = ['c','c~'],
    mass = 3.41,
    principal = 1,
    spin = 3,
    orbital = 1,
    J = 0,
    color = 1,
    charge = 0,
    ldme = 0.1074,
    texname = 'chic013P01'
)

chic0_13s18 = Boundstate(
    pdg_code = 9940011,
    name = 'chic0(1|3S18)',
    particles = ['c','c~'],
    mass = 3.61,
    principal = 1,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 8,
    charge = 0,
    ldme = 0.00215,
    texname = 'chic013S18'
)

chic1_13p11 = Boundstate(
    pdg_code = 20443,
    name = 'chic1(1|3P11)',
    particles = ['c','c~'],
    mass = 3.51,
    principal = 1,
    spin = 3,
    orbital = 1,
    J = 1,
    color = 1,
    charge = 0,
    ldme = 0.3223,
    texname = 'chic113P11'
)

chic1_13s18 = Boundstate(
    pdg_code = 9940023,
    name = 'chic1(1|3S18)',
    particles = ['c','c~'],
    mass = 3.71,
    principal = 1,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 8,
    charge = 0,
    ldme = 0.00645,
    texname = 'chic113S18'
)

chic2_13p21 = Boundstate(
    pdg_code = 445,
    name = 'chic2(1|3P21)',
    particles = ['c','c~'],
    mass = 3.56,
    principal = 1,
    spin = 3,
    orbital = 1,
    J = 2,
    color = 1,
    charge = 0,
    ldme = 0.5371,
    texname = 'chic213P21'
)

chic2_13s18 = Boundstate(
    pdg_code = 9940005,
    name = 'chic2(1|3S18)',
    particles = ['c','c~'],
    mass = 3.76,
    principal = 1,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 8,
    charge = 0,
    ldme = 0.0107,
    texname = 'chic213S18'
)


#=======================================================================
#  Bottomonia
#=======================================================================

#-----------------------------------------------------------------------
#  etab(1S)
#-----------------------------------------------------------------------
etab_11s01 = Boundstate(
    pdg_code = 551,
    name = 'etab(1|1S01)',
    particles = ['b','b~'],
    mass = 9.4,
    principal = 1,
    spin = 1,
    orbital = 0,
    J = 0,
    color = 1,
    charge = 0,
    ldme = 3.093,
    texname = 'etab11S01'
)

etab_11s08 = Boundstate(
    pdg_code = 9951001,
    name = 'etab(1|1S08)',
    particles = ['b','b~'],
    mass = 9.6,
    principal = 1,
    spin = 1,
    orbital = 0,
    J = 0,
    color = 8,
    charge = 0,
    ldme = 0.00920,
    texname = 'etab11S08'
)

etab_13s18 = Boundstate(
    pdg_code = 9950001,
    name = 'etab(1|3S18)',
    particles = ['b','b~'],
    mass = 9.6,
    principal = 1,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 8,
    charge = 0,
    ldme = 0.0208,
    texname = 'etab13S18'
)

etab_11p18 = Boundstate(
    pdg_code = 9956001,
    name = 'etab(1|1P18)',
    particles = ['b','b~'],
    mass = 9.6,
    principal = 1,
    spin = 1,
    orbital = 1,
    J = 1,
    color = 8,
    charge = 0,
    ldme = 2.07,
    texname = 'etab11P18'
)

#-----------------------------------------------------------------------
#  etab(2S)
#-----------------------------------------------------------------------
etab_21s01 = Boundstate(
    pdg_code = 100551,
    name = 'etab(2|1S01)',
    particles = ['b','b~'],
    mass = 10,
    principal = 2,
    spin = 1,
    orbital = 0,
    J = 0,
    color = 1,
    charge = 0,
    ldme = 1.544,
    texname = 'etab21S01'
)

etab_21s08 = Boundstate(
    pdg_code = 9951101,
    name = 'etab(2|1S08)',
    particles = ['b','b~'],
    mass = 10.2,
    principal = 2,
    spin = 1,
    orbital = 0,
    J = 0,
    color = 8,
    charge = 0,
    ldme = 0.0059,
    texname = 'etab21S08'
)

etab_23s18 = Boundstate(
    pdg_code = 9950101,
    name = 'etab(2|3S18)',
    particles = ['b','b~'],
    mass = 10.2,
    principal = 2,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 8,
    charge = 0,
    ldme = 0.0102,
    texname = 'etab23S18'
)

etab_21p18 = Boundstate(
    pdg_code = 9956101,
    name = 'etab(2|1P18)',
    particles = ['b','b~'],
    mass = 10.2,
    principal = 2,
    spin = 1,
    orbital = 1,
    J = 1,
    color = 8,
    charge = 0,
    ldme = 0.9,
    texname = 'etab21P18'
)

#-----------------------------------------------------------------------
#  etab(3S)
#-----------------------------------------------------------------------
etab_31s01 = Boundstate(
    pdg_code = 200551,
    name = 'etab(3|1S01)',
    particles = ['b','b~'],
    mass = 10.34,
    principal = 3,
    spin = 1,
    orbital = 0,
    J = 0,
    color = 1,
    charge = 0,
    ldme = 1.18,
    texname = 'etab31S01'
)

etab_31s08 = Boundstate(
    pdg_code = 9951201,
    name = 'etab(3|1S08)',
    particles = ['b','b~'],
    mass = 10.54,
    principal = 3,
    spin = 1,
    orbital = 0,
    J = 0,
    color = 8,
    charge = 0,
    ldme = 0.00373,
    texname = 'etab31S08'
)

etab_33s18 = Boundstate(
    pdg_code = 9950201,
    name = 'etab(3|3S18)',
    particles = ['b','b~'],
    mass = 10.54,
    principal = 3,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 8,
    charge = 0,
    ldme = 0.00725,
    texname = 'etab33S18'
)

etab_31p18 = Boundstate(
    pdg_code = 9956201,
    name = 'etab(3|1P18)',
    particles = ['b','b~'],
    mass = 10.54,
    principal = 3,
    spin = 1,
    orbital = 1,
    J = 1,
    color = 8,
    charge = 0,
    ldme = 0.375,
    texname = 'etab31P18'
)

#-----------------------------------------------------------------------
#  Upsilon(1S)
#-----------------------------------------------------------------------
upsilon_13s11 = Boundstate(
    pdg_code = 553,
    name = 'Upsilon(1|3S11)',
    particles = ['b','b~'],
    mass = 9.46,
    principal = 1,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 1,
    charge = 0,
    ldme = 9.28,
    texname = 'upsilon13S11'
)

upsilon_11s08 = Boundstate(
    pdg_code = 9951003,
    name = 'Upsilon(1|1S08)',
    particles = ['b','b~'],
    mass = 9.66,
    principal = 1,
    spin = 1,
    orbital = 0,
    J = 0,
    color = 8,
    charge = 0,
    ldme = 0.0208,
    texname = 'upsilon11S08'
)

upsilon_13s18 = Boundstate(
    pdg_code = 9950003,
    name = 'Upsilon(1|3S18)',
    particles = ['b','b~'],
    mass = 9.66,
    principal = 1,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 8,
    charge = 0,
    ldme = 0.0276,
    texname = 'upsilon13S18'
)

upsilon_13p08 = Boundstate(
    pdg_code = 9953003,
    name = 'Upsilon(1|3P08)',
    particles = ['b','b~'],
    mass = 9.66,
    principal = 1,
    spin = 3,
    orbital = 1,
    J = 0,
    color = 8,
    charge = 0,
    ldme = 0.69,
    texname = 'upsilon13P08'
)

upsilon_13p18 = Boundstate(
    pdg_code = 9954003,
    name = 'Upsilon(1|3P18)',
    particles = ['b','b~'],
    mass = 9.66,
    principal = 1,
    spin = 3,
    orbital = 1,
    J = 1,
    color = 8,
    charge = 0,
    ldme = 2.07,
    texname = 'upsilon13P18'
)

upsilon_13p28 = Boundstate(
    pdg_code = 9955003,
    name = 'Upsilon(1|3P28)',
    particles = ['b','b~'],
    mass = 9.66,
    principal = 1,
    spin = 3,
    orbital = 1,
    J = 2,
    color = 8,
    charge = 0,
    ldme = 3.45,
    texname = 'upsilon13P28'
)

#-----------------------------------------------------------------------
#  Upsilon(2S)
#-----------------------------------------------------------------------
upsilon_23s11 = Boundstate(
    pdg_code = 100553,
    name = 'Upsilon(2|3S11)',
    particles = ['b','b~'],
    mass = 10.02,
    principal = 2,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 1,
    charge = 0,
    ldme = 4.63,
    texname = 'upsilon23S11'
)

upsilon_21s08 = Boundstate(
    pdg_code = 9951103,
    name = 'Upsilon(2|1S08)',
    particles = ['b','b~'],
    mass = 10.22,
    principal = 2,
    spin = 1,
    orbital = 0,
    J = 0,
    color = 8,
    charge = 0,
    ldme = 0.0102,
    texname = 'upsilon21S08'
)

upsilon_23s18 = Boundstate(
    pdg_code = 9950103,
    name = 'Upsilon(2|3S18)',
    particles = ['b','b~'],
    mass = 10.22,
    principal = 2,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 8,
    charge = 0,
    ldme = 0.0177,
    texname = 'upsilon23S18'
)

upsilon_23p08 = Boundstate(
    pdg_code = 9953103,
    name = 'Upsilon(2|3P08)',
    particles = ['b','b~'],
    mass = 10.22,
    principal = 2,
    spin = 3,
    orbital = 1,
    J = 0,
    color = 8,
    charge = 0,
    ldme = 0.3,
    texname = 'upsilon23P08'
)

upsilon_23p18 = Boundstate(
    pdg_code = 9954103,
    name = 'Upsilon(2|3P18)',
    particles = ['b','b~'],
    mass = 10.22,
    principal = 2,
    spin = 3,
    orbital = 1,
    J = 1,
    color = 8,
    charge = 0,
    ldme = 0.9,
    texname = 'upsilon23P18'
)

upsilon_23p28 = Boundstate(
    pdg_code = 9955103,
    name = 'Upsilon(2|3P28)',
    particles = ['b','b~'],
    mass = 10.22,
    principal = 2,
    spin = 3,
    orbital = 1,
    J = 2,
    color = 8,
    charge = 0,
    ldme = 1.5,
    texname = 'upsilon23P28'
)

#-----------------------------------------------------------------------
#  Upsilon(3S)
#-----------------------------------------------------------------------
upsilon_33s11 = Boundstate(
    pdg_code = 200553,
    name = 'Upsilon(3|3S11)',
    particles = ['b','b~'],
    mass = 10.36,
    principal = 3,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 1,
    charge = 0,
    ldme = 3.54,
    texname = 'upsilon33S11'
)

upsilon_31s08 = Boundstate(
    pdg_code = 9951203,
    name = 'Upsilon(3|1S08)',
    particles = ['b','b~'],
    mass = 10.56,
    principal = 3,
    spin = 1,
    orbital = 0,
    J = 0,
    color = 8,
    charge = 0,
    ldme = 0.00725,
    texname = 'upsilon31S08'
)

upsilon_33s18 = Boundstate(
    pdg_code = 9950203,
    name = 'Upsilon(3|3S18)',
    particles = ['b','b~'],
    mass = 10.56,
    principal = 3,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 8,
    charge = 0,
    ldme = 0.0112,
    texname = 'upsilon33S18'
)

upsilon_33p08 = Boundstate(
    pdg_code = 9953203,
    name = 'Upsilon(3|3P08)',
    particles = ['b','b~'],
    mass = 10.56,
    principal = 3,
    spin = 3,
    orbital = 1,
    J = 0,
    color = 8,
    charge = 0,
    ldme = 0.125,
    texname = 'upsilon33P08'
)

upsilon_33p18 = Boundstate(
    pdg_code = 9954203,
    name = 'Upsilon(3|3P18)',
    particles = ['b','b~'],
    mass = 10.56,
    principal = 3,
    spin = 3,
    orbital = 1,
    J = 1,
    color = 8,
    charge = 0,
    ldme = 0.375,
    texname = 'upsilon33P18'
)

upsilon_33p28 = Boundstate(
    pdg_code = 9955203,
    name = 'Upsilon(3|3P28)',
    particles = ['b','b~'],
    mass = 10.56,
    principal = 3,
    spin = 3,
    orbital = 1,
    J = 2,
    color = 8,
    charge = 0,
    ldme = 0.625,
    texname = 'upsilon33P28'
)

#-----------------------------------------------------------------------
#  hb(1P)
#-----------------------------------------------------------------------
hb_11p11 = Boundstate(
    pdg_code = 10553,
    name = 'hb(1|1P11)',
    particles = ['b','b~'],
    mass = 9.90,
    principal = 1,
    spin = 1,
    orbital = 1,
    J = 1,
    color = 1,
    charge = 0,
    ldme = 6.089,
    texname = 'hb11P11'
)

hb_11s08 = Boundstate(
    pdg_code = 9951013,
    name = 'hb(1|1S08)',
    particles = ['b','b~'],
    mass = 10.10,
    principal = 1,
    spin = 1,
    orbital = 0,
    J = 0,
    color = 8,
    charge = 0,
    ldme = 0.019,
    texname = 'hb11S08'
)

#-----------------------------------------------------------------------
#  hb(2P)
#-----------------------------------------------------------------------
hb_21p11 = Boundstate(
    pdg_code = 110553,
    name = 'hb(2|1P11)',
    particles = ['b','b~'],
    mass = 10.26,
    principal = 2,
    spin = 1,
    orbital = 1,
    J = 1,
    color = 1,
    charge = 0,
    ldme = 7.103,
    texname = 'hb21P11'
)

hb_21s08 = Boundstate(
    pdg_code = 9951113,
    name = 'hb(2|1S08)',
    particles = ['b','b~'],
    mass = 10.46,
    principal = 2,
    spin = 1,
    orbital = 0,
    J = 0,
    color = 8,
    charge = 0,
    ldme = 0.028,
    texname = 'hb21S08'
)

#-----------------------------------------------------------------------
#  hb(3P)
#-----------------------------------------------------------------------
hb_31p11 = Boundstate(
    pdg_code = 210553,
    name = 'hb(3|1P11)',
    particles = ['b','b~'],
    mass = 10.51,
    principal = 3,
    spin = 1,
    orbital = 1,
    J = 1,
    color = 1,
    charge = 0,
    ldme = 7.709,
    texname = 'hb31P11'
)

hb_31s08 = Boundstate(
    pdg_code = 9951213,
    name = 'hb(3|1S08)',
    particles = ['b','b~'],
    mass = 10.71,
    principal = 3,
    spin = 1,
    orbital = 0,
    J = 0,
    color = 8,
    charge = 0,
    ldme = 0.047,
    texname = 'hb31S08'
)

#-----------------------------------------------------------------------
#  chib(1P)
#-----------------------------------------------------------------------
chib0_13p01 = Boundstate(
    pdg_code = 10551,
    name = 'chib0(1|3P01)',
    particles = ['b','b~'],
    mass = 9.86,
    principal = 1,
    spin = 3,
    orbital = 1,
    J = 0,
    color = 1,
    charge = 0,
    ldme = 2.03,
    texname = 'chib013P01'
)

chib0_13s18 = Boundstate(
    pdg_code = 9950011,
    name = 'chib0(1|3S18)',
    particles = ['b','b~'],
    mass = 10.06,
    principal = 1,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 8,
    charge = 0,
    ldme = 0.006,
    texname = 'chib013S18'
)

chib1_13p11 = Boundstate(
    pdg_code = 20553,
    name = 'chib1(1|3P11)',
    particles = ['b','b~'],
    mass = 9.89,
    principal = 1,
    spin = 3,
    orbital = 1,
    J = 1,
    color = 1,
    charge = 0,
    ldme = 6.089,
    texname = 'chib113P11'
)

chib1_13s18 = Boundstate(
    pdg_code = 9950023,
    name = 'chib1(1|3S18)',
    particles = ['b','b~'],
    mass = 10.09,
    principal = 1,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 8,
    charge = 0,
    ldme = 0.019,
    texname = 'chib113S18'
)

chib2_13p21 = Boundstate(
    pdg_code = 555,
    name = 'chib2(1|3P21)',
    particles = ['b','b~'],
    mass = 9.91,
    principal = 1,
    spin = 3,
    orbital = 1,
    J = 2,
    color = 1,
    charge = 0,
    ldme = 10.15,
    texname = 'chib213P21'
)

chib2_13s18 = Boundstate(
    pdg_code = 9950005,
    name = 'chib2(1|3S18)',
    particles = ['b','b~'],
    mass = 10.11,
    principal = 1,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 8,
    charge = 0,
    ldme = 0.0315,
    texname = 'chib213S18'
)

#-----------------------------------------------------------------------
#  chib(2P)
#-----------------------------------------------------------------------
chib0_23p01 = Boundstate(
    pdg_code = 110551,
    name = 'chib0(2|3P01)',
    particles = ['b','b~'],
    mass = 10.23,
    principal = 2,
    spin = 3,
    orbital = 1,
    J = 0,
    color = 1,
    charge = 0,
    ldme = 2.368,
    texname = 'chib023P01'
)

chib0_23s18 = Boundstate(
    pdg_code = 9950111,
    name = 'chib0(2|3S18)',
    particles = ['b','b~'],
    mass = 10.43,
    principal = 2,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 8,
    charge = 0,
    ldme = 0.011,
    texname = 'chib023S18'
)

chib1_23p11 = Boundstate(
    pdg_code = 120553,
    name = 'chib1(2|3P11)',
    particles = ['b','b~'],
    mass = 10.26,
    principal = 2,
    spin = 3,
    orbital = 1,
    J = 1,
    color = 1,
    charge = 0,
    ldme = 7.103,
    texname = 'chib123P11'
)

chib1_23s18 = Boundstate(
    pdg_code = 9950123,
    name = 'chib1(2|3S18)',
    particles = ['b','b~'],
    mass = 10.46,
    principal = 2,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 8,
    charge = 0,
    ldme = 0.028,
    texname = 'chib123S18'
)

chib2_23p21 = Boundstate(
    pdg_code = 100555,
    name = 'chib2(2|3P21)',
    particles = ['b','b~'],
    mass = 10.27,
    principal = 2,
    spin = 3,
    orbital = 1,
    J = 2,
    color = 1,
    charge = 0,
    ldme = 11.84,
    texname = 'chib223P21'
)

chib2_23s18 = Boundstate(
    pdg_code = 9950105,
    name = 'chib2(2|3S18)',
    particles = ['b','b~'],
    mass = 10.47,
    principal = 2,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 8,
    charge = 0,
    ldme = 0.046,
    texname = 'chib223S18'
)

#-----------------------------------------------------------------------
#  chib(3P)
#-----------------------------------------------------------------------
chib0_33p01 = Boundstate(
    pdg_code = 210551,
    name = 'chib0(3|3P01)',
    particles = ['b','b~'],
    mass = 10.49,
    principal = 3,
    spin = 3,
    orbital = 1,
    J = 0,
    color = 1,
    charge = 0,
    ldme = 2.57,
    texname = 'chib033P01'
)

chib0_33s18 = Boundstate(
    pdg_code = 9950211,
    name = 'chib0(3|3S18)',
    particles = ['b','b~'],
    mass = 10.69,
    principal = 3,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 8,
    charge = 0,
    ldme = 0.016,
    texname = 'chib033S18'
)

chib1_33p11 = Boundstate(
    pdg_code = 220553,
    name = 'chib1(3|3P11)',
    particles = ['b','b~'],
    mass = 10.51,
    principal = 3,
    spin = 3,
    orbital = 1,
    J = 1,
    color = 1,
    charge = 0,
    ldme = 7.709,
    texname = 'chib133P11'
)

chib1_33s18 = Boundstate(
    pdg_code = 9950223,
    name = 'chib1(3|3S18)',
    particles = ['b','b~'],
    mass = 10.71,
    principal = 3,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 8,
    charge = 0,
    ldme = 0.047,
    texname = 'chib133S18'
)

chib2_33p21 = Boundstate(
    pdg_code = 200555,
    name = 'chib2(3|3P21)',
    particles = ['b','b~'],
    mass = 10.52,
    principal = 3,
    spin = 3,
    orbital = 1,
    J = 2,
    color = 1,
    charge = 0,
    ldme = 12.85,
    texname = 'chib233P21'
)

chib2_33s18 = Boundstate(
    pdg_code = 9950205,
    name = 'chib2(3|3S18)',
    particles = ['b','b~'],
    mass = 10.72,
    principal = 3,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 8,
    charge = 0,
    ldme = 0.079,
    texname = 'chib233S18'
)


#=======================================================================
#  Charmed B mesons
#=======================================================================

#-----------------------------------------------------------------------
#  Bc+(1S)
#-----------------------------------------------------------------------
Bc__plus__11s01 = Boundstate(
    pdg_code = 541,
    name = 'Bc+(1|1S01)',
    particles = ['c','b~'],
    mass = 6.27,
    principal = 1,
    spin = 1,
    orbital = 0,
    J = 0,
    color = 1,
    charge = 1,
    ldme = 0.784,
    texname = 'Bc+11S01'
)

Bc__plus__11s08 = Boundstate(
    pdg_code = 9971001,
    name = 'Bc+(1|1S08)',
    particles = ['c','b~'],
    mass = 6.47,
    principal = 1,
    spin = 1,
    orbital = 0,
    J = 0,
    color = 8,
    charge = 1,
    ldme = 0.00784,
    texname = 'Bc+11S08'
)

Bc__plus__13s18 = Boundstate(
    pdg_code = 9970001,
    name = 'Bc+(1|3S18)',
    particles = ['c','b~'],
    mass = 6.47,
    principal = 1,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 8,
    charge = 1,
    ldme = 0.00784,
    texname = 'Bc+13S18'
)

Bc__plus__11p18 = Boundstate(
    pdg_code = 9976001,
    name = 'Bc+(1|1P18)',
    particles = ['c','b~'],
    mass = 6.47,
    principal = 1,
    spin = 1,
    orbital = 1,
    J = 1,
    color = 8,
    charge = 1,
    ldme = 0.07656,
    texname = 'Bc+11P18'
)

#-----------------------------------------------------------------------
#  Bc+(2S)
#-----------------------------------------------------------------------
Bc__plus__21s01 = Boundstate(
    pdg_code = 100541,
    name = 'Bc+(2|1S01)',
    particles = ['c','b~'],
    mass = 6.87,
    principal = 2,
    spin = 1,
    orbital = 0,
    J = 0,
    color = 1,
    charge = 1,
    ldme = 0.469,
    texname = 'Bc+21S01'
)

Bc__plus__21s08 = Boundstate(
    pdg_code = 9971101,
    name = 'Bc+(2|1S08)',
    particles = ['c','b~'],
    mass = 7.07,
    principal = 2,
    spin = 1,
    orbital = 0,
    J = 0,
    color = 8,
    charge = 1,
    ldme = 0.00469,
    texname = 'Bc+21S08'
)

Bc__plus__23s18 = Boundstate(
    pdg_code = 9970101,
    name = 'Bc+(2|3S18)',
    particles = ['c','b~'],
    mass = 7.07,
    principal = 2,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 8,
    charge = 1,
    ldme = 0.00469,
    texname = 'Bc+23S18'
)

Bc__plus__21p18 = Boundstate(
    pdg_code = 9976101,
    name = 'Bc+(2|1P18)',
    particles = ['c','b~'],
    mass = 7.07,
    principal = 2,
    spin = 1,
    orbital = 1,
    J = 1,
    color = 8,
    charge = 1,
    ldme = 0.0458,
    texname = 'Bc+21P18'
)

#-----------------------------------------------------------------------
#  B*c+(1S)
#-----------------------------------------------------------------------
B__star__c__plus__13s11 = Boundstate(
    pdg_code = 543,
    name = 'B*c+(1|3S11)',
    particles = ['c','b~'],
    mass = 6.33,
    principal = 1,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 1,
    charge = 1,
    ldme = 2.352,
    texname = 'B*c+13S11'
)

B__star__c__plus__11s08 = Boundstate(
    pdg_code = 9971003,
    name = 'B*c+(1|1S08)',
    particles = ['c','b~'],
    mass = 6.53,
    principal = 1,
    spin = 1,
    orbital = 0,
    J = 0,
    color = 8,
    charge = 1,
    ldme = 0.00784,
    texname = 'B*c+11S08'
)

B__star__c__plus__13s18 = Boundstate(
    pdg_code = 9970003,
    name = 'B*c+(1|3S18)',
    particles = ['c','b~'],
    mass = 6.53,
    principal = 1,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 8,
    charge = 1,
    ldme = 0.02352,
    texname = 'B*c+13S18'
)

B__star__c__plus__13p08 = Boundstate(
    pdg_code = 9973003,
    name = 'B*c+(1|3P08)',
    mass = 6.53,
    particles = ['c','b~'],
    principal = 1,
    spin = 3,
    orbital = 1,
    J = 0,
    color = 8,
    charge = 1,
    ldme = 0.02552,
    texname = 'B*c+13P08'
)

B__star__c__plus__13p18 = Boundstate(
    pdg_code = 9974003,
    name = 'B*c+(1|3P18)',
    mass = 6.53,
    particles = ['c','b~'],
    principal = 1,
    spin = 3,
    orbital = 1,
    J = 1,
    color = 8,
    charge = 1,
    ldme = 0.07656,
    texname = 'B*c+13P18'
)

B__star__c__plus__13p28 = Boundstate(
    pdg_code = 9975003,
    name = 'B*c+(1|3P28)',
    mass = 6.53,
    particles = ['c','b~'],
    principal = 1,
    spin = 3,
    orbital = 1,
    J = 2,
    color = 8,
    charge = 1,
    ldme = 0.1276,
    texname = 'B*c+13P28'
)

#-----------------------------------------------------------------------
#  B*c+(2S)
#-----------------------------------------------------------------------
B__star__c__plus__23s11 = Boundstate(
    pdg_code = 100543,
    name = 'B*c+(2|3S11)',
    particles = ['c','b~'],
    mass = 6.90,
    principal = 2,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 1,
    charge = 1,
    ldme = 1.41,
    texname = 'B*c+23S11'
)

B__star__c__plus__21s08 = Boundstate(
    pdg_code = 9971103,
    name = 'B*c+(2|1S08)',
    particles = ['c','b~'],
    mass = 7.10,
    principal = 2,
    spin = 1,
    orbital = 0,
    J = 0,
    color = 8,
    charge = 1,
    ldme = 0.00469,
    texname = 'B*c+21S08'
)

B__star__c__plus__23s18 = Boundstate(
    pdg_code = 9970103,
    name = 'B*c+(2|3S18)',
    particles = ['c','b~'],
    mass = 7.10,
    principal = 2,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 8,
    charge = 1,
    ldme = 0.0141,
    texname = 'B*c+23S18'
)

B__star__c__plus__23p08 = Boundstate(
    pdg_code = 9973103,
    name = 'B*c+(2|3P08)',
    mass = 7.10,
    particles = ['c','b~'],
    principal = 2,
    spin = 3,
    orbital = 1,
    J = 0,
    color = 8,
    charge = 1,
    ldme = 0.0153,
    texname = 'B*c+23P08'
)

B__star__c__plus__23p18 = Boundstate(
    pdg_code = 9974103,
    name = 'B*c+(2|3P18)',
    mass = 7.10,
    particles = ['c','b~'],
    principal = 2,
    spin = 3,
    orbital = 1,
    J = 1,
    color = 8,
    charge = 1,
    ldme = 0.0458,
    texname = 'B*c+23P18'
)

B__star__c__plus__23p28 = Boundstate(
    pdg_code = 9975103,
    name = 'B*c+(2|3P28)',
    mass = 7.10,
    particles = ['c','b~'],
    principal = 2,
    spin = 3,
    orbital = 1,
    J = 2,
    color = 8,
    charge = 1,
    ldme = 0.0764,
    texname = 'B*c+23P28'
)

#-----------------------------------------------------------------------
#  Bc1L+(1P)
#-----------------------------------------------------------------------
Bc1L__plus__11p11 = Boundstate(
    pdg_code = 10543,
    name = 'Bc1L+(1|1P11)',
    particles = ['c','b~'],
    mass = 6.77,
    principal = 1,
    spin = 1,
    orbital = 1,
    J = 1,
    color = 1,
    charge = 1,
    ldme = 0.864,
    texname = 'Bc1L+11P11'
)

Bc1L__plus__11s08 = Boundstate(
    pdg_code = 9971013,
    name = 'Bc1L+(1|1S08)',
    particles = ['c','b~'],
    mass = 6.97,
    principal = 1,
    spin = 1,
    orbital = 0,
    J = 0,
    color = 8,
    charge = 1,
    ldme = 0.0884,
    texname = 'Bc1L+11S08'
)

#-----------------------------------------------------------------------
#  B*c+(1P)
#-----------------------------------------------------------------------
B__star__c0__plus__13p01 = Boundstate(
    pdg_code = 10541,
    name = 'B*c0+(1|3P01)',
    particles = ['c','b~'],
    mass = 6.70,
    principal = 1,
    spin = 3,
    orbital = 1,
    J = 0,
    color = 1,
    charge = 1,
    ldme = 0.288,
    texname = 'B*c0+13P01'
)

B__star__c0__plus__13s18 = Boundstate(
    pdg_code = 9970011,
    name = 'B*c0+(1|3S18)',
    particles = ['c','b~'],
    mass = 6.90,
    principal = 1,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 8,
    charge = 1,
    ldme = 0.0295,
    texname = 'B*c0+13S18'
)

Bc1H__plus__13p11 = Boundstate(
    pdg_code = 20543,
    name = 'Bc1H+(1|3P11)',
    particles = ['c','b~'],
    mass = 6.76,
    principal = 1,
    spin = 3,
    orbital = 1,
    J = 1,
    color = 1,
    charge = 1,
    ldme = 0.864,
    texname = 'Bc1H+13P11'
)

Bc1H__plus__13s18 = Boundstate(
    pdg_code = 9970023,
    name = 'Bc1H+(1|3S18)',
    particles = ['c','b~'],
    mass = 6.96,
    principal = 1,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 8,
    charge = 1,
    ldme = 0.0884,
    texname = 'Bc1H+13S18'
)

B__star__c2__plus__13p21 = Boundstate(
    pdg_code = 545,
    name = 'B*c2+(1|3P21)',
    particles = ['c','b~'],
    mass = 6.79,
    principal = 1,
    spin = 3,
    orbital = 1,
    J = 2,
    color = 1,
    charge = 1,
    ldme = 1.44,
    texname = 'B*c2+13P21'
)

B__star__c2__plus__13s18 = Boundstate(
    pdg_code = 9970005,
    name = 'B*c2+(1|3S18)',
    particles = ['c','b~'],
    mass = 6.99,
    principal = 1,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 8,
    charge = 1,
    ldme = 0.147,
    texname = 'B*c2+13S18'
)

#-----------------------------------------------------------------------
#  Bc-(1S)
#-----------------------------------------------------------------------
Bc__minus__11s01 = Boundstate(
    pdg_code = -541,
    name = 'Bc-(1|1S01)',
    particles = ['b','c~'],
    mass = 6.27,
    principal = 1,
    spin = 1,
    orbital = 0,
    J = 0,
    color = 1,
    charge = -1,
    ldme = 0.784,
    texname = 'Bc-11S01'
)

Bc__minus__11s08 = Boundstate(
    pdg_code = -9971001,
    name = 'Bc-(1|1S08)',
    particles = ['b','c~'],
    mass = 6.47,
    principal = 1,
    spin = 1,
    orbital = 0,
    J = 0,
    color = 8,
    charge = -1,
    ldme = 0.00784,
    texname = 'Bc-11S08'
)

Bc__minus__13s18 = Boundstate(
    pdg_code = -9970001,
    name = 'Bc-(1|3S18)',
    particles = ['b','c~'],
    mass = 6.47,
    principal = 1,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 8,
    charge = -1,
    ldme = 0.00784,
    texname = 'Bc-13S18'
)

Bc__minus__11p18 = Boundstate(
    pdg_code = -9976001,
    name = 'Bc-(1|1P18)',
    particles = ['b','c~'],
    mass = 6.47,
    principal = 1,
    spin = 1,
    orbital = 1,
    J = 1,
    color = 8,
    charge = -1,
    ldme = 0.07656,
    texname = 'Bc-11P18'
)

#-----------------------------------------------------------------------
#  Bc-(2S)
#-----------------------------------------------------------------------
Bc__minus__21s01 = Boundstate(
    pdg_code = -100541,
    name = 'Bc-(2|1S01)',
    particles = ['b','c~'],
    mass = 6.87,
    principal = 2,
    spin = 1,
    orbital = 0,
    J = 0,
    color = 1,
    charge = -1,
    ldme = 0.469,
    texname = 'Bc-21S01'
)

Bc__minus__21s08 = Boundstate(
    pdg_code = -9971101,
    name = 'Bc-(2|1S08)',
    particles = ['b','c~'],
    mass = 7.07,
    principal = 2,
    spin = 1,
    orbital = 0,
    J = 0,
    color = 8,
    charge = -1,
    ldme = 0.00469,
    texname = 'Bc-21S08'
)

Bc__minus__23s18 = Boundstate(
    pdg_code = -9970101,
    name = 'Bc-(2|3S18)',
    particles = ['b','c~'],
    mass = 7.07,
    principal = 2,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 8,
    charge = -1,
    ldme = 0.00469,
    texname = 'Bc-23S18'
)

Bc__minus__21p18 = Boundstate(
    pdg_code = -9976101,
    name = 'Bc-(2|1P18)',
    particles = ['b','c~'],
    mass = 7.07,
    principal = 2,
    spin = 1,
    orbital = 1,
    J = 1,
    color = 8,
    charge = -1,
    ldme = 0.0458,
    texname = 'Bc-21P18'
)

#-----------------------------------------------------------------------
#  B*c-(1S)
#-----------------------------------------------------------------------
B__star__c__minus__13s11 = Boundstate(
    pdg_code = -543,
    name = 'B*c-(1|3S11)',
    particles = ['b','c~'],
    mass = 6.33,
    principal = 1,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 1,
    charge = -1,
    ldme = 2.352,
    texname = 'B*c-13S11'
)

B__star__c__minus__11s08 = Boundstate(
    pdg_code = -9971003,
    name = 'B*c-(1|1S08)',
    particles = ['b','c~'],
    mass = 6.53,
    principal = 1,
    spin = 1,
    orbital = 0,
    J = 0,
    color = 8,
    charge = -1,
    ldme = 0.00784,
    texname = 'B*c-11S08'
)

B__star__c__minus__13s18 = Boundstate(
    pdg_code = -9970003,
    name = 'B*c-(1|3S18)',
    particles = ['b','c~'],
    mass = 6.53,
    principal = 1,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 8,
    charge = -1,
    ldme = 0.02352,
    texname = 'B*c-13S18'
)

B__star__c__minus__13p08 = Boundstate(
    pdg_code = -9973003,
    name = 'B*c-(1|3P08)',
    mass = 6.53,
    particles = ['b','c~'],
    principal = 1,
    spin = 3,
    orbital = 1,
    J = 0,
    color = 8,
    charge = -1,
    ldme = 0.02552,
    texname = 'B*c-13P08'
)

B__star__c__minus__13p18 = Boundstate(
    pdg_code = -9974003,
    name = 'B*c-(1|3P18)',
    mass = 6.53,
    particles = ['b','c~'],
    principal = 1,
    spin = 3,
    orbital = 1,
    J = 1,
    color = 8,
    charge = -1,
    ldme = 0.07656,
    texname = 'B*c-13P18'
)

B__star__c__minus__13p28 = Boundstate(
    pdg_code = -9975003,
    name = 'B*c-(1|3P28)',
    mass = 6.53,
    particles = ['b','c~'],
    principal = 1,
    spin = 3,
    orbital = 1,
    J = 2,
    color = 8,
    charge = -1,
    ldme = 0.1276,
    texname = 'B*c-13P28'
)

#-----------------------------------------------------------------------
#  B*c-(2S)
#-----------------------------------------------------------------------
B__star__c__minus__23s11 = Boundstate(
    pdg_code = -100543,
    name = 'B*c-(2|3S11)',
    particles = ['b','c~'],
    mass = 6.90,
    principal = 2,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 1,
    charge = -1,
    ldme = 1.41,
    texname = 'B*c-23S11'
)

B__star__c__minus__21s08 = Boundstate(
    pdg_code = -9971103,
    name = 'B*c-(2|1S08)',
    particles = ['b','c~'],
    mass = 7.10,
    principal = 2,
    spin = 1,
    orbital = 0,
    J = 0,
    color = 8,
    charge = -1,
    ldme = 0.00469,
    texname = 'B*c-21S08'
)

B__star__c__minus__23s18 = Boundstate(
    pdg_code = -9970103,
    name = 'B*c-(2|3S18)',
    particles = ['b','c~'],
    mass = 7.10,
    principal = 2,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 8,
    charge = -1,
    ldme = 0.0141,
    texname = 'B*c-23S18'
)

B__star__c__minus__23p08 = Boundstate(
    pdg_code = -9973103,
    name = 'B*c-(2|3P08)',
    mass = 7.10,
    particles = ['b','c~'],
    principal = 2,
    spin = 3,
    orbital = 1,
    J = 0,
    color = 8,
    charge = -1,
    ldme = 0.0153,
    texname = 'B*c-23P08'
)

B__star__c__minus__23p18 = Boundstate(
    pdg_code = -9974103,
    name = 'B*c-(2|3P18)',
    mass = 7.10,
    particles = ['b','c~'],
    principal = 2,
    spin = 3,
    orbital = 1,
    J = 1,
    color = 8,
    charge = -1,
    ldme = 0.0458,
    texname = 'B*c-23P18'
)

B__star__c__minus__23p28 = Boundstate(
    pdg_code = -9975103,
    name = 'B*c-(2|3P28)',
    mass = 7.10,
    particles = ['b','c~'],
    principal = 2,
    spin = 3,
    orbital = 1,
    J = 2,
    color = 8,
    charge = -1,
    ldme = 0.0764,
    texname = 'B*c-23P28'
)

#-----------------------------------------------------------------------
#  Bc1L-(1P)
#-----------------------------------------------------------------------
Bc1L__minus__11p11 = Boundstate(
    pdg_code = -10543,
    name = 'Bc1L-(1|1P11)',
    particles = ['b','c~'],
    mass = 6.77,
    principal = 1,
    spin = 1,
    orbital = 1,
    J = 1,
    color = 1,
    charge = -1,
    ldme = 0.864,
    texname = 'Bc1L-11P11'
)

Bc1L__minus__11s08 = Boundstate(
    pdg_code = -9971013,
    name = 'Bc1L-(1|1S08)',
    particles = ['b','c~'],
    mass = 6.97,
    principal = 1,
    spin = 1,
    orbital = 0,
    J = 0,
    color = 8,
    charge = -1,
    ldme = 0.0884,
    texname = 'Bc1L-11S08'
)

#-----------------------------------------------------------------------
#  B*c-(1P)
#-----------------------------------------------------------------------
B__star__c0__minus__13p01 = Boundstate(
    pdg_code = -10541,
    name = 'B*c0-(1|3P01)',
    particles = ['b','c~'],
    mass = 6.70,
    principal = 1,
    spin = 3,
    orbital = 1,
    J = 0,
    color = 1,
    charge = -1,
    ldme = 0.288,
    texname = 'B*c0-13P01'
)

B__star__c0__minus__13s18 = Boundstate(
    pdg_code = -9970011,
    name = 'B*c0-(1|3S18)',
    particles = ['b','c~'],
    mass = 6.90,
    principal = 1,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 8,
    charge = -1,
    ldme = 0.0295,
    texname = 'B*c0-13S18'
)

Bc1H__minus__13p11 = Boundstate(
    pdg_code = -20543,
    name = 'Bc1H-(1|3P11)',
    particles = ['b','c~'],
    mass = 6.76,
    principal = 1,
    spin = 3,
    orbital = 1,
    J = 1,
    color = 1,
    charge = -1,
    ldme = 0.864,
    texname = 'Bc1H-13P11'
)

Bc1H__minus__13s18 = Boundstate(
    pdg_code = -9970023,
    name = 'Bc1H-(1|3S18)',
    particles = ['b','c~'],
    mass = 6.96,
    principal = 1,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 8,
    charge = -1,
    ldme = 0.0884,
    texname = 'Bc1H-13S18'
)

B__star__c2__minus__13p21 = Boundstate(
    pdg_code = -545,
    name = 'B*c2-(1|3P21)',
    particles = ['b','c~'],
    mass = 6.79,
    principal = 1,
    spin = 3,
    orbital = 1,
    J = 2,
    color = 1,
    charge = -1,
    ldme = 1.44,
    texname = 'B*c2-13P21'
)

B__star__c2__minus__13s18 = Boundstate(
    pdg_code = -9970005,
    name = 'B*c2-(1|3S18)',
    particles = ['b','c~'],
    mass = 6.99,
    principal = 1,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 8,
    charge = -1,
    ldme = 0.147,
    texname = 'B*c2-13S18'
)


#=======================================================================
#  Leptonia
#=======================================================================

#-----------------------------------------------------------------------
#  positronium
#-----------------------------------------------------------------------
ps_11s0 = Boundstate(
    pdg_code = 99011001,
    name = 'Ps(1|1S0)',
    particles = ['e-','e+'],
    mass = 0.001022,
    principal = 1,
    spin = 1,
    orbital = 0,
    J = 0,
    color = 1,
    charge = 0,
    texname = 'Ps11S0'
)

ps_13s1 = Boundstate(
    pdg_code = 99011003,
    name = 'Ps(1|3S1)',
    particles = ['e-','e+'],
    mass = 0.001022,
    principal = 1,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 1,
    charge = 0,
    texname = 'Ps13S1'
)

ps_21p1 = Boundstate(
    pdg_code = 99011113,
    name = 'Ps(2|1P1)',
    particles = ['e-','e+'],
    mass = 0.001022,
    principal = 2,
    spin = 1,
    orbital = 1,
    J = 1,
    color = 1,
    charge = 0,
    texname = 'Ps21P1'
)

ps_23p0 = Boundstate(
    pdg_code = 99011111,
    name = 'Ps(2|3P0)',
    particles = ['e-','e+'],
    mass = 0.001022,
    principal = 2,
    spin = 3,
    orbital = 1,
    J = 0,
    color = 1,
    charge = 0,
    texname = 'Ps23P0'
)

ps_23p1 = Boundstate(
    pdg_code = 99011123,
    name = 'Ps(2|3P1)',
    particles = ['e-','e+'],
    mass = 0.001022,
    principal = 2,
    spin = 3,
    orbital = 1,
    J = 1,
    color = 1,
    charge = 0,
    texname = 'Ps23P1'
)

ps_23p2 = Boundstate(
    pdg_code = 99011105,
    name = 'Ps(2|3P2)',
    particles = ['e-','e+'],
    mass = 0.001022,
    principal = 2,
    spin = 3,
    orbital = 1,
    J = 2,
    color = 1,
    charge = 0,
    texname = 'Ps23P2'
)

#-----------------------------------------------------------------------
#  muonium
#-----------------------------------------------------------------------
mo_11s0 = Boundstate(
    pdg_code = 99031001,
    name = 'mo(1|1S0)',
    particles = ['e-','mu+'],
    mass = 0.106171,
    principal = 1,
    spin = 1,
    orbital = 0,
    J = 0,
    color = 1,
    charge = 0,
    texname = 'mo11S0'
)

mo_13s1 = Boundstate(
    pdg_code = 99031003,
    name = 'mo(1|3S1)',
    particles = ['e-','mu+'],
    mass = 0.106171,
    principal = 1,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 1,
    charge = 0,
    texname = 'mo13S1'
)

mo_21p1 = Boundstate(
    pdg_code = 99031113,
    name = 'mo(2|1P1)',
    particles = ['e-','mu+'],
    mass = 0.106171,
    principal = 2,
    spin = 1,
    orbital = 1,
    J = 1,
    color = 1,
    charge = 0,
    texname = 'mo21P1'
)

mo_23p0 = Boundstate(
    pdg_code = 99031111,
    name = 'mo(2|3P0)',
    particles = ['e-','mu+'],
    mass = 0.106171,
    principal = 2,
    spin = 3,
    orbital = 1,
    J = 0,
    color = 1,
    charge = 0,
    texname = 'mo23P0'
)

mo_23p1 = Boundstate(
    pdg_code = 99031123,
    name = 'mo(2|3P1)',
    particles = ['e-','mu+'],
    mass = 0.106171,
    principal = 2,
    spin = 3,
    orbital = 1,
    J = 1,
    color = 1,
    charge = 0,
    texname = 'mo23P1'
)

mo_23p2 = Boundstate(
    pdg_code = 99031105,
    name = 'mo(2|3P2)',
    particles = ['e-','mu+'],
    mass = 0.106171,
    principal = 2,
    spin = 3,
    orbital = 1,
    J = 2,
    color = 1,
    charge = 0,
    texname = 'mo23P2'
)

mo_11s0__tilde__ = Boundstate(
    pdg_code = -99031001,
    name = 'mo~(1|1S0)',
    particles = ['mu-','e+'],
    mass = 0.106171,
    principal = 1,
    spin = 1,
    orbital = 0,
    J = 0,
    color = 1,
    charge = 0,
    texname = 'mo~11S0'
)

mo_13s1__tilde__ = Boundstate(
    pdg_code = -99031003,
    name = 'mo~(1|3S1)',
    particles = ['mu-','e+'],
    mass = 0.106171,
    principal = 1,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 1,
    charge = 0,
    texname = 'mo~13S1'
)

mo_21p1__tilde__ = Boundstate(
    pdg_code = -99031113,
    name = 'mo~(2|1P1)',
    particles = ['mu-','e+'],
    mass = 0.106171,
    principal = 2,
    spin = 1,
    orbital = 1,
    J = 1,
    color = 1,
    charge = 0,
    texname = 'mo~21P1'
)

mo_23p0__tilde__ = Boundstate(
    pdg_code = -99031111,
    name = 'mo~(2|3P0)',
    particles = ['mu-','e+'],
    mass = 0.106171,
    principal = 2,
    spin = 3,
    orbital = 1,
    J = 0,
    color = 1,
    charge = 0,
    texname = 'mo~23P0'
)

mo_23p1__tilde__ = Boundstate(
    pdg_code = -99031123,
    name = 'mo~(2|3P1)',
    particles = ['mu-','e+'],
    mass = 0.106171,
    principal = 2,
    spin = 3,
    orbital = 1,
    J = 1,
    color = 1,
    charge = 0,
    texname = 'mo~23P1'
)

mo_23p2__tilde__ = Boundstate(
    pdg_code = -99031105,
    name = 'mo~(2|3P2)',
    particles = ['mu-','e+'],
    mass = 0.106171,
    principal = 2,
    spin = 3,
    orbital = 1,
    J = 2,
    color = 1,
    charge = 0,
    texname = 'mo~23P2'
)

#-----------------------------------------------------------------------
#  tauonium
#-----------------------------------------------------------------------
to_11s0 = Boundstate(
    pdg_code = 99051001,
    name = 'to(1|1S0)',
    particles = ['e-','ta+'],
    mass = 1.777511,
    principal = 1,
    spin = 1,
    orbital = 0,
    J = 0,
    color = 1,
    charge = 0,
    texname = 'to11S0'
)

to_13s1 = Boundstate(
    pdg_code = 99051003,
    name = 'to(1|3S1)',
    particles = ['e-','ta+'],
    mass = 1.777511,
    principal = 1,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 1,
    charge = 0,
    texname = 'to13S1'
)

to_21p1 = Boundstate(
    pdg_code = 99051113,
    name = 'to(2|1P1)',
    particles = ['e-','ta+'],
    mass = 1.777511,
    principal = 2,
    spin = 1,
    orbital = 1,
    J = 1,
    color = 1,
    charge = 0,
    texname = 'to21P1'
)

to_23p0 = Boundstate(
    pdg_code = 99051111,
    name = 'to(2|3P0)',
    particles = ['e-','ta+'],
    mass = 1.777511,
    principal = 2,
    spin = 3,
    orbital = 1,
    J = 0,
    color = 1,
    charge = 0,
    texname = 'to23P0'
)

to_23p1 = Boundstate(
    pdg_code = 99051123,
    name = 'to(2|3P1)',
    particles = ['e-','ta+'],
    mass = 1.777511,
    principal = 2,
    spin = 3,
    orbital = 1,
    J = 1,
    color = 1,
    charge = 0,
    texname = 'to23P1'
)

to_23p2 = Boundstate(
    pdg_code = 99051105,
    name = 'to(2|3P2)',
    particles = ['e-','ta+'],
    mass = 1.777511,
    principal = 2,
    spin = 3,
    orbital = 1,
    J = 2,
    color = 1,
    charge = 0,
    texname = 'to23P2'
)

to_11s0__tilde__ = Boundstate(
    pdg_code = -99051001,
    name = 'to~(1|1S0)',
    particles = ['ta-','e+'],
    mass = 1.777511,
    principal = 1,
    spin = 1,
    orbital = 0,
    J = 0,
    color = 1,
    charge = 0,
    texname = 'to~11S0'
)

to_13s1__tilde__ = Boundstate(
    pdg_code = -99051003,
    name = 'to~(1|3S1)',
    particles = ['ta-','e+'],
    mass = 1.777511,
    principal = 1,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 1,
    charge = 0,
    texname = 'to~13S1'
)

to_21p1__tilde__ = Boundstate(
    pdg_code = -99051113,
    name = 'to~(2|1P1)',
    particles = ['ta-','e+'],
    mass = 1.777511,
    principal = 2,
    spin = 1,
    orbital = 1,
    J = 1,
    color = 1,
    charge = 0,
    texname = 'to~21P1'
)

to_23p0__tilde__ = Boundstate(
    pdg_code = -99051111,
    name = 'to~(2|3P0)',
    particles = ['ta-','e+'],
    mass = 1.777511,
    principal = 2,
    spin = 3,
    orbital = 1,
    J = 0,
    color = 1,
    charge = 0,
    texname = 'to~23P0'
)

to_23p1__tilde__ = Boundstate(
    pdg_code = -99051123,
    name = 'to~(2|3P1)',
    particles = ['ta-','e+'],
    mass = 1.777511,
    principal = 2,
    spin = 3,
    orbital = 1,
    J = 1,
    color = 1,
    charge = 0,
    texname = 'to~23P1'
)

to_23p2__tilde__ = Boundstate(
    pdg_code = -99051105,
    name = 'to~(2|3P2)',
    particles = ['ta-','e+'],
    mass = 1.777511,
    principal = 2,
    spin = 3,
    orbital = 1,
    J = 2,
    color = 1,
    charge = 0,
    texname = 'to~23P2'
)

#-----------------------------------------------------------------------
#  true muonium
#-----------------------------------------------------------------------
mumu_11s0 = Boundstate(
    pdg_code = 99033001,
    name = 'mumu(1|1S0)',
    particles = ['mu-','mu+'],
    mass = 0.21132,
    principal = 1,
    spin = 1,
    orbital = 0,
    J = 0,
    color = 1,
    charge = 0,
    texname = 'mumu11S0'
)

mumu_13s1 = Boundstate(
    pdg_code = 99033003,
    name = 'mumu(1|3S1)',
    particles = ['mu-','mu+'],
    mass = 0.21132,
    principal = 1,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 1,
    charge = 0,
    texname = 'mumu13S1'
)

mumu_21p1 = Boundstate(
    pdg_code = 99033113,
    name = 'mumu(2|1P1)',
    particles = ['mu-','mu+'],
    mass = 0.21132,
    principal = 2,
    spin = 1,
    orbital = 1,
    J = 1,
    color = 1,
    charge = 0,
    texname = 'mumu21P1'
)

mumu_23p0 = Boundstate(
    pdg_code = 99033111,
    name = 'mumu(2|3P0)',
    particles = ['mu-','mu+'],
    mass = 0.21132,
    principal = 2,
    spin = 3,
    orbital = 1,
    J = 0,
    color = 1,
    charge = 0,
    texname = 'mumu23P0'
)

mumu_23p1 = Boundstate(
    pdg_code = 99033123,
    name = 'mumu(2|3P1)',
    particles = ['mu-','mu+'],
    mass = 0.21132,
    principal = 2,
    spin = 3,
    orbital = 1,
    J = 1,
    color = 1,
    charge = 0,
    texname = 'mumu23P1'
)

mumu_23p2 = Boundstate(
    pdg_code = 99033105,
    name = 'mumu(2|3P2)',
    particles = ['mu-','mu+'],
    mass = 0.21132,
    principal = 2,
    spin = 3,
    orbital = 1,
    J = 2,
    color = 1,
    charge = 0,
    texname = 'mumu23P2'
)

#-----------------------------------------------------------------------
#  mu-tauonium
#-----------------------------------------------------------------------
mto_11s0 = Boundstate(
    pdg_code = 99053001,
    name = 'mto(1|1S0)',
    particles = ['mu-','ta+'],
    mass = 1.88266,
    principal = 1,
    spin = 1,
    orbital = 0,
    J = 0,
    color = 1,
    charge = 0,
    texname = 'mto11S0'
)

mto_13s1 = Boundstate(
    pdg_code = 99053003,
    name = 'mto(1|3S1)',
    particles = ['mu-','ta+'],
    mass = 1.88266,
    principal = 1,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 1,
    charge = 0,
    texname = 'mto13S1'
)

mto_21p1 = Boundstate(
    pdg_code = 99053113,
    name = 'mto(2|1P1)',
    particles = ['mu-','ta+'],
    mass = 1.88266,
    principal = 2,
    spin = 1,
    orbital = 1,
    J = 1,
    color = 1,
    charge = 0,
    texname = 'mto21P1'
)

mto_23p0 = Boundstate(
    pdg_code = 99053111,
    name = 'mto(2|3P0)',
    particles = ['mu-','ta+'],
    mass = 1.88266,
    principal = 2,
    spin = 3,
    orbital = 1,
    J = 0,
    color = 1,
    charge = 0,
    texname = 'mto23P0'
)

mto_23p1 = Boundstate(
    pdg_code = 99053123,
    name = 'mto(2|3P1)',
    particles = ['mu-','ta+'],
    mass = 1.88266,
    principal = 2,
    spin = 3,
    orbital = 1,
    J = 1,
    color = 1,
    charge = 0,
    texname = 'mto23P1'
)

mto_23p2 = Boundstate(
    pdg_code = 99053105,
    name = 'mto(2|3P2)',
    particles = ['mu-','ta+'],
    mass = 1.88266,
    principal = 2,
    spin = 3,
    orbital = 1,
    J = 2,
    color = 1,
    charge = 0,
    texname = 'mto23P2'
)

mto_11s0__tilde__ = Boundstate(
    pdg_code = -99053001,
    name = 'mto~(1|1S0)',
    particles = ['ta-','mu+'],
    mass = 1.88266,
    principal = 1,
    spin = 1,
    orbital = 0,
    J = 0,
    color = 1,
    charge = 0,
    texname = 'mto~11S0'
)

mto_13s1__tilde__ = Boundstate(
    pdg_code = -99053003,
    name = 'mto~(1|3S1)',
    particles = ['ta-','mu+'],
    mass = 1.88266,
    principal = 1,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 1,
    charge = 0,
    texname = 'mto~13S1'
)

mto_21p1__tilde__ = Boundstate(
    pdg_code = -99053113,
    name = 'mto~(2|1P1)',
    particles = ['ta-','mu+'],
    mass = 1.88266,
    principal = 2,
    spin = 1,
    orbital = 1,
    J = 1,
    color = 1,
    charge = 0,
    texname = 'mto~21P1'
)

mto_23p0__tilde__ = Boundstate(
    pdg_code = -99053111,
    name = 'mto~(2|3P0)',
    particles = ['ta-','mu+'],
    mass = 1.88266,
    principal = 2,
    spin = 3,
    orbital = 1,
    J = 0,
    color = 1,
    charge = 0,
    texname = 'mto~23P0'
)

mto_23p1__tilde__ = Boundstate(
    pdg_code = -99053123,
    name = 'mto~(2|3P1)',
    particles = ['ta-','mu+'],
    mass = 1.88266,
    principal = 2,
    spin = 3,
    orbital = 1,
    J = 1,
    color = 1,
    charge = 0,
    texname = 'mto~23P1'
)

mto_23p2__tilde__ = Boundstate(
    pdg_code = -99053105,
    name = 'mto~(2|3P2)',
    particles = ['ta-','mu+'],
    mass = 1.88266,
    principal = 2,
    spin = 3,
    orbital = 1,
    J = 2,
    color = 1,
    charge = 0,
    texname = 'mto~23P2'
)

#-----------------------------------------------------------------------
#  ditauonium
#-----------------------------------------------------------------------
tata_11s0 = Boundstate(
    pdg_code = 99055001,
    name = 'tata(1|1S0)',
    particles = ['ta-','ta+'],
    mass = 3.554,
    principal = 1,
    spin = 1,
    orbital = 0,
    J = 0,
    color = 1,
    charge = 0,
    texname = 'tata11S0'
)

tata_13s1 = Boundstate(
    pdg_code = 99055003,
    name = 'tata(1|3S1)',
    particles = ['ta-','ta+'],
    mass = 3.554,
    principal = 1,
    spin = 3,
    orbital = 0,
    J = 1,
    color = 1,
    charge = 0,
    texname = 'tata13S1'
)

tata_21p1 = Boundstate(
    pdg_code = 99055113,
    name = 'tata(2|1P1)',
    particles = ['ta-','ta+'],
    mass = 3.554,
    principal = 2,
    spin = 1,
    orbital = 1,
    J = 1,
    color = 1,
    charge = 0,
    texname = 'tata21P1'
)

tata_23p0 = Boundstate(
    pdg_code = 99055111,
    name = 'tata(2|3P0)',
    particles = ['ta-','ta+'],
    mass = 3.554,
    principal = 2,
    spin = 3,
    orbital = 1,
    J = 0,
    color = 1,
    charge = 0,
    texname = 'tata23P0'
)

tata_23p1 = Boundstate(
    pdg_code = 99055123,
    name = 'tata(2|3P1)',
    particles = ['ta-','ta+'],
    mass = 3.554,
    principal = 2,
    spin = 3,
    orbital = 1,
    J = 1,
    color = 1,
    charge = 0,
    texname = 'tata23P1'
)

tata_23p2 = Boundstate(
    pdg_code = 99055105,
    name = 'tata(2|3P2)',
    particles = ['ta-','ta+'],
    mass = 3.554,
    principal = 2,
    spin = 3,
    orbital = 1,
    J = 2,
    color = 1,
    charge = 0,
    texname = 'tata23P2'
)
