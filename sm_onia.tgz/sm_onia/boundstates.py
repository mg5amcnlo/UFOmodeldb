from importlib import reload
import object_library
reload(object_library)
from object_library import all_boundstates, Boundstate


#=======================================================================
#  Charmonia
#=======================================================================

#-----------------------------------------------------------------------
#  etac(1S)
#-----------------------------------------------------------------------
etac_11s01 = Boundstate(pdg_code = 441,
                        name = 'etac(1|1S01)',
                        particles = ['c','c~'],
                        principal = 1,
                        spin = 1,
                        orbital = 0,
                        J = 0,
                        color = 1,
                        charge = 0,
                        texname = 'etac11S01')

etac_11s08 = Boundstate(pdg_code = 9941001,
                        name = 'etac(1|1S08)',
                        particles = ['c','c~'],
                        principal = 1,
                        spin = 1,
                        orbital = 0,
                        J = 0,
                        color = 8,
                        charge = 0,
                        texname = 'etac11S08')

etac_13s18 = Boundstate(pdg_code = 9940001,
                        name = 'etac(1|3S18)',
                        particles = ['c','c~'],
                        principal = 1,
                        spin = 3,
                        orbital = 0,
                        J = 1,
                        color = 8,
                        charge = 0,
                        texname = 'etac13S18')

#-----------------------------------------------------------------------
#  etac(2S)
#-----------------------------------------------------------------------
etac_21s01 = Boundstate(pdg_code = 100441,
                        name = 'etac(2|1S01)',
                        particles = ['c','c~'],
                        principal = 2,
                        spin = 1,
                        orbital = 0,
                        J = 0,
                        color = 1,
                        charge = 0,
                        texname = 'etac11S01')

etac_21s08 = Boundstate(pdg_code = 9941101,
                        name = 'etac(2|1S08)',
                        particles = ['c','c~'],
                        principal = 2,
                        spin = 1,
                        orbital = 0,
                        J = 0,
                        color = 8,
                        charge = 0,
                        texname = 'etac11S08')

etac_23s18 = Boundstate(pdg_code = 9940101,
                        name = 'etac(2|3S18)',
                        particles = ['c','c~'],
                        principal = 2,
                        spin = 3,
                        orbital = 0,
                        J = 1,
                        color = 8,
                        charge = 0,
                        texname = 'etac13S18')

#-----------------------------------------------------------------------
#  psi(1S)
#-----------------------------------------------------------------------
psi_13s11 = Boundstate(pdg_code = 443,
                       name = 'Jpsi(1|3S11)',
                       particles = ['c','c~'],
                       principal = 1,
                       spin = 3,
                       orbital = 0,
                       J = 1,
                       color = 1,
                       charge = 0,
                       texname = 'jpsi13S11')

psi_11s08 = Boundstate(pdg_code = 9941003,
                       name = 'Jpsi(1|1S08)',
                       particles = ['c','c~'],
                       principal = 1,
                       spin = 1,
                       orbital = 0,
                       J = 0,
                       color = 8,
                       charge = 0,
                       texname = 'jpsi11S08')

psi_13s18 = Boundstate(pdg_code = 9940003,
                       name = 'Jpsi(1|3S18)',
                       particles = ['c','c~'],
                       principal = 1,
                       spin = 3,
                       orbital = 0,
                       J = 1,
                       color = 8,
                       charge = 0,
                       texname = 'jpsi13S18')

#-----------------------------------------------------------------------
#  psi(2S)
#-----------------------------------------------------------------------
psi_23s11 = Boundstate(pdg_code = 100443,
                       name = 'psi(2|3S11)',
                       particles = ['c','c~'],
                       principal = 2,
                       spin = 3,
                       orbital = 0,
                       J = 1,
                       color = 1,
                       charge = 0,
                       texname = 'psi23S11')

psi_21s08 = Boundstate(pdg_code = 9941103,
                       name = 'psi(2|1S08)',
                       particles = ['c','c~'],
                       principal = 2,
                       spin = 1,
                       orbital = 0,
                       J = 0,
                       color = 8,
                       charge = 0,
                       texname = 'psi21S08')

psi_23s18 = Boundstate(pdg_code = 9940103,
                       name = 'psi(2|3S18)',
                       particles = ['c','c~'],
                       principal = 2,
                       spin = 3,
                       orbital = 0,
                       J = 1,
                       color = 8,
                       charge = 0,
                       texname = 'psi23S18')


#=======================================================================
#  Charmed B mesons
#=======================================================================

#-----------------------------------------------------------------------
#  Bc+(1S)
#-----------------------------------------------------------------------
Bc__plus__11s01 = Boundstate(pdg_code = 541,
                             name = 'Bc+(1|1S01)',
                             particles = ['c','b~'],
                             principal = 1,
                             spin = 1,
                             orbital = 0,
                             J = 0,
                             color = 1,
                             charge = 1,
                             texname = 'Bc+11S01')

Bc__plus__11s08 = Boundstate(pdg_code = 9971001,
                             name = 'Bc+(1|1S08)',
                             particles = ['c','b~'],
                             principal = 1,
                             spin = 1,
                             orbital = 0,
                             J = 0,
                             color = 8,
                             charge = 1,
                             texname = 'Bc+11S08')

Bc__plus__13s18 = Boundstate(pdg_code = 9970001,
                             name = 'Bc+(1|3S18)',
                             particles = ['c','b~'],
                             principal = 1,
                             spin = 3,
                             orbital = 0,
                             J = 1,
                             color = 8,
                             charge = 1,
                             texname = 'Bc+13S18')

#-----------------------------------------------------------------------
#  Bc+(2S)
#-----------------------------------------------------------------------
Bc__plus__21s01 = Boundstate(pdg_code = 100541,
                             name = 'Bc+(2|1S01)',
                             particles = ['c','b~'],
                             principal = 2,
                             spin = 1,
                             orbital = 0,
                             J = 0,
                             color = 1,
                             charge = 1,
                             texname = 'Bc+21S01')

Bc__plus__21s08 = Boundstate(pdg_code = 9971101,
                             name = 'Bc+(2|1S08)',
                             particles = ['c','b~'],
                             principal = 2,
                             spin = 1,
                             orbital = 0,
                             J = 0,
                             color = 8,
                             charge = 1,
                             texname = 'Bc+21S08')

Bc__plus__23s18 = Boundstate(pdg_code = 9970101,
                             name = 'Bc+(2|3S18)',
                             particles = ['c','b~'],
                             principal = 2,
                             spin = 3,
                             orbital = 0,
                             J = 1,
                             color = 8,
                             charge = 1,
                             texname = 'Bc+23S18')

#-----------------------------------------------------------------------
#  B*c+(1S)
#-----------------------------------------------------------------------
B__star__c__plus__13s11 = Boundstate(pdg_code = 543,
                                     name = 'B*c+(1|3S11)',
                                     particles = ['c','b~'],
                                     principal = 1,
                                     spin = 3,
                                     orbital = 0,
                                     J = 1,
                                     color = 1,
                                     charge = 1,
                                     texname = 'B*c+13S11')

B__star__c__plus__11s08 = Boundstate(pdg_code = 9971003,
                                     name = 'B*c+(1|1S08)',
                                     particles = ['c','b~'],
                                     principal = 1,
                                     spin = 1,
                                     orbital = 0,
                                     J = 0,
                                     color = 8,
                                     charge = 1,
                                     texname = 'B*c+11S08')

B__star__c__plus__13s18 = Boundstate(pdg_code = 9970003,
                                     name = 'B*c+(1|3S18)',
                                     particles = ['c','b~'],
                                     principal = 1,
                                     spin = 3,
                                     orbital = 0,
                                     J = 1,
                                     color = 8,
                                     charge = 1,
                                     texname = 'B*c+13S18')

#-----------------------------------------------------------------------
#  B*c+(2S)
#-----------------------------------------------------------------------
B__star__c__plus__23s11 = Boundstate(pdg_code = 100543,
                                     name = 'B*c+(2|3S11)',
                                     particles = ['c','b~'],
                                     principal = 2,
                                     spin = 3,
                                     orbital = 0,
                                     J = 1,
                                     color = 1,
                                     charge = 1,
                                     texname = 'B*c+23S11')

B__star__c__plus__21s08 = Boundstate(pdg_code = 9971103,
                                     name = 'B*c+(2|1S08)',
                                     particles = ['c','b~'],
                                     principal = 2,
                                     spin = 1,
                                     orbital = 0,
                                     J = 0,
                                     color = 8,
                                     charge = 1,
                                     texname = 'B*c+21S08')

B__star__c__plus__23s18 = Boundstate(pdg_code = 9970103,
                                     name = 'B*c+(2|3S18)',
                                     particles = ['c','b~'],
                                     principal = 2,
                                     spin = 3,
                                     orbital = 0,
                                     J = 1,
                                     color = 8,
                                     charge = 1,
                                     texname = 'B*c+23S18')

#-----------------------------------------------------------------------
#  Bc-(1S)
#-----------------------------------------------------------------------
Bc__minus__11s01 = Boundstate(pdg_code = -541,
                              name = 'Bc-(1|1S01)',
                              particles = ['b','c~'],
                              principal = 1,
                              spin = 1,
                              orbital = 0,
                              J = 0,
                              color = 1,
                              charge = -1,
                              texname = 'Bc-11S01')

Bc__minus__11s08 = Boundstate(pdg_code = -9971001,
                              name = 'Bc-(1|1S08)',
                              particles = ['b','c~'],
                              principal = 1,
                              spin = 1,
                              orbital = 0,
                              J = 0,
                              color = 8,
                              charge = -1,
                              texname = 'Bc-11S08')

Bc__minus__13s18 = Boundstate(pdg_code = -9970001,
                              name = 'Bc-(1|3S18)',
                              particles = ['b','c~'],
                              principal = 1,
                              spin = 3,
                              orbital = 0,
                              J = 1,
                              color = 8,
                              charge = -1,
                              texname = 'Bc-13S18')

#-----------------------------------------------------------------------
#  Bc-(2S)
#-----------------------------------------------------------------------
Bc__minus__21s01 = Boundstate(pdg_code = -100541,
                              name = 'Bc-(2|1S01)',
                              particles = ['b','c~'],
                              principal = 2,
                              spin = 1,
                              orbital = 0,
                              J = 0,
                              color = 1,
                              charge = -1,
                              texname = 'Bc-21S01')

Bc__minus__21s08 = Boundstate(pdg_code = -9971101,
                              name = 'Bc-(2|1S08)',
                              particles = ['b','c~'],
                              principal = 2,
                              spin = 1,
                              orbital = 0,
                              J = 0,
                              color = 8,
                              charge = -1,
                              texname = 'Bc-21S08')

Bc__minus__23s18 = Boundstate(pdg_code = -9970101,
                              name = 'Bc-(2|3S18)',
                              particles = ['b','c~'],
                              principal = 2,
                              spin = 3,
                              orbital = 0,
                              J = 1,
                              color = 8,
                              charge = -1,
                              texname = 'Bc-23S18')

#-----------------------------------------------------------------------
#  B*c-(1S)
#-----------------------------------------------------------------------
B__star__c__minus__13s11 = Boundstate(pdg_code = -543,
                                      name = 'B*c-(1|3S11)',
                                      particles = ['b','c~'],
                                      principal = 1,
                                      spin = 3,
                                      orbital = 0,
                                      J = 1,
                                      color = 1,
                                      charge = -1,
                                      texname = 'B*c-13S11')

B__star__c__minus__11s08 = Boundstate(pdg_code = -9971003,
                                      name = 'B*c-(1|1S08)',
                                      particles = ['b','c~'],
                                      principal = 1,
                                      spin = 1,
                                      orbital = 0,
                                      J = 0,
                                      color = 8,
                                      charge = -1,
                                      texname = 'B*c-11S08')

B__star__c__minus__13s18 = Boundstate(pdg_code = -9970003,
                                      name = 'B*c-(1|3S18)',
                                      particles = ['b','c~'],
                                      principal = 1,
                                      spin = 3,
                                      orbital = 0,
                                      J = 1,
                                      color = 8,
                                      charge = -1,
                                      texname = 'B*c-13S18')

#-----------------------------------------------------------------------
#  B*c-(2S)
#-----------------------------------------------------------------------
B__star__c__minus__23s11 = Boundstate(pdg_code = -100543,
                                      name = 'B*c-(2|3S11)',
                                      particles = ['b','c~'],
                                      principal = 2,
                                      spin = 3,
                                      orbital = 0,
                                      J = 1,
                                      color = 1,
                                      charge = -1,
                                      texname = 'B*c-23S11')

B__star__c__minus__21s08 = Boundstate(pdg_code = -9971103,
                                      name = 'B*c-(2|1S08)',
                                      particles = ['b','c~'],
                                      principal = 2,
                                      spin = 1,
                                      orbital = 0,
                                      J = 0,
                                      color = 8,
                                      charge = -1,
                                      texname = 'B*c-21S08')

B__star__c__minus__23s18 = Boundstate(pdg_code = -9970103,
                                      name = 'B*c-(2|3S18)',
                                      particles = ['b','c~'],
                                      principal = 2,
                                      spin = 3,
                                      orbital = 0,
                                      J = 1,
                                      color = 8,
                                      charge = -1,
                                      texname = 'B*c-23S18')


#=======================================================================
#  Bottomonia
#=======================================================================

#-----------------------------------------------------------------------
#  eta(1S)
#-----------------------------------------------------------------------
etab_11s01 = Boundstate(pdg_code = 551,
                        name = 'etab(1|1S01)',
                        particles = ['b','b~'],
                        principal = 1,
                        spin = 1,
                        orbital = 0,
                        J = 0,
                        color = 1,
                        charge = 0,
                        texname = 'etab11S01')

etab_11s08 = Boundstate(pdg_code = 9951001,
                        name = 'etab(1|1S08)',
                        particles = ['b','b~'],
                        principal = 1,
                        spin = 1,
                        orbital = 0,
                        J = 0,
                        color = 8,
                        charge = 0,
                        texname = 'etab11S08')

etab_13s18 = Boundstate(pdg_code = 9950001,
                        name = 'etab(1|3S18)',
                        particles = ['b','b~'],
                        principal = 1,
                        spin = 3,
                        orbital = 0,
                        J = 1,
                        color = 8,
                        charge = 0,
                        texname = 'etab13S18')

#-----------------------------------------------------------------------
#  etab(2S)
#-----------------------------------------------------------------------
etab_21s01 = Boundstate(pdg_code = 100551,
                        name = 'etab(2|1S01)',
                        particles = ['b','b~'],
                        principal = 2,
                        spin = 1,
                        orbital = 0,
                        J = 0,
                        color = 1,
                        charge = 0,
                        texname = 'etab21S01')

etab_21s08 = Boundstate(pdg_code = 9951101,
                        name = 'etab(2|1S08)',
                        particles = ['b','b~'],
                        principal = 2,
                        spin = 1,
                        orbital = 0,
                        J = 0,
                        color = 8,
                        charge = 0,
                        texname = 'etab21S08')

etab_23s18 = Boundstate(pdg_code = 9950101,
                        name = 'etab(2|3S18)',
                        particles = ['b','b~'],
                        principal = 2,
                        spin = 3,
                        orbital = 0,
                        J = 1,
                        color = 8,
                        charge = 0,
                        texname = 'etab23S18')

#-----------------------------------------------------------------------
#  etab(3S)
#-----------------------------------------------------------------------
etab_31s01 = Boundstate(pdg_code = 200551,
                        name = 'etab(3|1S01)',
                        particles = ['b','b~'],
                        principal = 3,
                        spin = 1,
                        orbital = 0,
                        J = 0,
                        color = 1,
                        charge = 0,
                        texname = 'etab31S01')

etab_31s08 = Boundstate(pdg_code = 9951201,
                        name = 'etab(3|1S08)',
                        particles = ['b','b~'],
                        principal = 3,
                        spin = 1,
                        orbital = 0,
                        J = 0,
                        color = 8,
                        charge = 0,
                        texname = 'etab31S08')

etab_33s18 = Boundstate(pdg_code = 9950201,
                        name = 'etab(3|3S18)',
                        particles = ['b','b~'],
                        principal = 3,
                        spin = 3,
                        orbital = 0,
                        J = 1,
                        color = 8,
                        charge = 0,
                        texname = 'etab33S18')

#-----------------------------------------------------------------------
#  Upsilon(1S)
#-----------------------------------------------------------------------
upsilon_13s11 = Boundstate(pdg_code = 553,
                           name = 'Upsilon(1|3S11)',
                           particles = ['b','b~'],
                           principal = 1,
                           spin = 3,
                           orbital = 0,
                           J = 1,
                           color = 1,
                           charge = 0,
                           texname = 'upsilon13S11')

upsilon_11s08 = Boundstate(pdg_code = 9951003,
                           name = 'Upsilon(1|1S08)',
                           particles = ['b','b~'],
                           principal = 1,
                           spin = 1,
                           orbital = 0,
                           J = 0,
                           color = 8,
                           charge = 0,
                           texname = 'upsilon11S08')

upsilon_13s18 = Boundstate(pdg_code = 9950003,
                           name = 'Upsilon(1|3S18)',
                           particles = ['b','b~'],
                           principal = 1,
                           spin = 3,
                           orbital = 0,
                           J = 1,
                           color = 8,
                           charge = 0,
                           texname = 'upsilon13S18')

#-----------------------------------------------------------------------
#  Upsilon(2S)
#-----------------------------------------------------------------------
upsilon_23s11 = Boundstate(pdg_code = 100553,
                           name = 'Upsilon(2|3S11)',
                           particles = ['b','b~'],
                           principal = 2,
                           spin = 3,
                           orbital = 0,
                           J = 1,
                           color = 1,
                           charge = 0,
                           texname = 'upsilon23S11')

upsilon_21s08 = Boundstate(pdg_code = 9951103,
                           name = 'Upsilon(2|1S08)',
                           particles = ['b','b~'],
                           principal = 2,
                           spin = 1,
                           orbital = 0,
                           J = 0,
                           color = 8,
                           charge = 0,
                           texname = 'upsilon21S08')

upsilon_23s18 = Boundstate(pdg_code = 9950103,
                           name = 'Upsilon(2|3S18)',
                           particles = ['b','b~'],
                           principal = 2,
                           spin = 3,
                           orbital = 0,
                           J = 1,
                           color = 8,
                           charge = 0,
                           texname = 'upsilon23S18')

#-----------------------------------------------------------------------
#  Upsilon(3S)
#-----------------------------------------------------------------------
upsilon_33s11 = Boundstate(pdg_code = 200553,
                           name = 'Upsilon(3|3S11)',
                           particles = ['b','b~'],
                           principal = 3,
                           spin = 3,
                           orbital = 0,
                           J = 1,
                           color = 1,
                           charge = 0,
                           texname = 'upsilon33S11')

upsilon_31s08 = Boundstate(pdg_code = 9951203,
                           name = 'Upsilon(3|1S08)',
                           particles = ['b','b~'],
                           principal = 3,
                           spin = 1,
                           orbital = 0,
                           J = 0,
                           color = 8,
                           charge = 0,
                           texname = 'upsilon31S08')

upsilon_33s18 = Boundstate(pdg_code = 9950203,
                           name = 'Upsilon(3|3S18)',
                           particles = ['b','b~'],
                           principal = 3,
                           spin = 3,
                           orbital = 0,
                           J = 1,
                           color = 8,
                           charge = 0,
                           texname = 'upsilon33S18')


#=======================================================================
#  Leptonia
#=======================================================================

#-----------------------------------------------------------------------
#  positronium
#-----------------------------------------------------------------------
ps_11s0 = Boundstate(pdg_code = 99011001,
                     name = 'Ps(1|1S0)',
                     particles = ['e-','e+'],
                     principal = 1,
                     spin = 1,
                     orbital = 0,
                     J = 0,
                     color = 1,
                     charge = 0,
                     texname = 'Ps11S0')

ps_13s1 = Boundstate(pdg_code = 99011003,
                     name = 'Ps(1|3S1)',
                     particles = ['e-','e+'],
                     principal = 1,
                     spin = 3,
                     orbital = 0,
                     J = 1,
                     color = 1,
                     charge = 0,
                     texname = 'Ps13S1')

#-----------------------------------------------------------------------
#  muonium
#-----------------------------------------------------------------------
mo_11s0 = Boundstate(pdg_code = 99031001,
                     name = 'mo(1|1S0)',
                     particles = ['e-','mu+'],
                     principal = 1,
                     spin = 1,
                     orbital = 0,
                     J = 0,
                     color = 1,
                     charge = 0,
                     texname = 'mo11S0')

mo_13s1 = Boundstate(pdg_code = 99031003,
                     name = 'mo(1|3S1)',
                     particles = ['e-','mu+'],
                     principal = 1,
                     spin = 3,
                     orbital = 0,
                     J = 1,
                     color = 1,
                     charge = 0,
                     texname = 'mo13S1')

anti_mo_11s0 = Boundstate(pdg_code = -99031001,
                          name = 'mo~(1|1S0)',
                          particles = ['mu-','e+'],
                          principal = 1,
                          spin = 1,
                          orbital = 0,
                          J = 0,
                          color = 1,
                          charge = 0,
                          texname = 'mo~11S0')

anti_mo_13s1 = Boundstate(pdg_code = -99031003,
                          name = 'mo~(1|3S1)',
                          particles = ['mu-','e+'],
                          principal = 1,
                          spin = 3,
                          orbital = 0,
                          J = 1,
                          color = 1,
                          charge = 0,
                          texname = 'mo~13S1')

#-----------------------------------------------------------------------
#  tauonium
#-----------------------------------------------------------------------
to_11s0 = Boundstate(pdg_code = 99051001,
                     name = 'to(1|1S0)',
                     particles = ['e-','ta+'],
                     principal = 1,
                     spin = 1,
                     orbital = 0,
                     J = 0,
                     color = 1,
                     charge = 0,
                     texname = 'to11S0')

to_13s1 = Boundstate(pdg_code = 99051003,
                     name = 'to(1|3S1)',
                     particles = ['e-','ta+'],
                     principal = 1,
                     spin = 3,
                     orbital = 0,
                     J = 1,
                     color = 1,
                     charge = 0,
                     texname = 'to13S1')

anti_to_11s0 = Boundstate(pdg_code = -99051001,
                          name = 'to~(1|1S0)',
                          particles = ['ta-','e+'],
                          principal = 1,
                          spin = 1,
                          orbital = 0,
                          J = 0,
                          color = 1,
                          charge = 0,
                          texname = 'to~11S0')

anti_to_13s1 = Boundstate(pdg_code = -99051003,
                          name = 'to~(1|3S1)',
                          particles = ['ta-','e+'],
                          principal = 1,
                          spin = 3,
                          orbital = 0,
                          J = 1,
                          color = 1,
                          charge = 0,
                          texname = 'to~13S1')

#-----------------------------------------------------------------------
#  true muonium
#-----------------------------------------------------------------------
mumu_11s0 = Boundstate(pdg_code = 99033001,
                       name = 'mumu(1|1S0)',
                       particles = ['mu-','mu+'],
                       principal = 1,
                       spin = 1,
                       orbital = 0,
                       J = 0,
                       color = 1,
                       charge = 0,
                       texname = 'mumu11S0')

mumu_13s1 = Boundstate(pdg_code = 99033003,
                       name = 'mumu(1|3S1)',
                       particles = ['mu-','mu+'],
                       principal = 1,
                       spin = 3,
                       orbital = 0,
                       J = 1,
                       color = 1,
                       charge = 0,
                       texname = 'mumu13S1')

#-----------------------------------------------------------------------
#  ditauonium
#-----------------------------------------------------------------------
tata_11s0 = Boundstate(pdg_code = 99055001,
                       name = 'tata(1|1S0)',
                       particles = ['ta-','ta+'],
                       principal = 1,
                       spin = 1,
                       orbital = 0,
                       J = 0,
                       color = 1,
                       charge = 0,
                       texname = 'tata11S0')

tata_13s1 = Boundstate(pdg_code = 99055003,
                       name = 'tata(1|3S1)',
                       particles = ['ta-','ta+'],
                       principal = 1,
                       spin = 3,
                       orbital = 0,
                       J = 1,
                       color = 1,
                       charge = 0,
                       texname = 'tata13S1')