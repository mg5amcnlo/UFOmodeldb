# This file is part of the UFO.
#
# This file contains definitions for functions that
# are extensions of the cmath library, and correspond
# either to functions that are in cmath, but inconvenient
# to access from there (e.g. z.conjugate()),
# or functions that are simply not defined.
#
#

__date__ = "22 July 2010"
__author__ = "claude.duhr@durham.ac.uk"

import cmath
from object_library import all_functions, Function

#
# shortcuts for functions from cmath
#

complexconjugate = Function(name = 'complexconjugate',
                            arguments = ('z',),
                            expression = 'z.conjugate()')


re = Function(name = 're',
              arguments = ('z',),
              expression = 'z.real')

im = Function(name = 'im',
              arguments = ('z',),
              expression = 'z.imag')

# Auxiliary functions for NLO

cond = Function(name = 'cond',
                arguments = ('condition','ExprTrue','ExprFalse'),
                expression = '(ExprTrue if condition==0.0 else ExprFalse)')

reglog = Function(name = 'reglog',
                arguments = ('z',),
                expression = '(0.0 if z==0.0 else cmath.log(z))')

reglogp = Function(name = 'reglogp',
                   arguments = ('z',),
                   expression = '(0.0 if z.imag==0.0 and z.real==0.0 else ( cmath.log(z) + 2*cmath.pi*1j if (z.real < 0.0 and z.imag < 0.0) else cmath.log(z) ) )')

reglogm = Function(name = 'reglogm',
                arguments = ('z',),
                expression = '(0.0 if z.imag==0.0 and z.real==0.0 else ( cmath.log(z) - 2*cmath.pi*1j if (z.real < 0.0 and z.imag > 0.0) else cmath.log(z) ) )')

grreglog = Function(name = 'grreglog',
                arguments = ('logswitch','z1','z2'),
                argstype  = (float, complex, complex),
                expression = '(cmath.log(z1) if (z1.real>=0.0 or z2.real>=0.0 or z1.imag*z2.imag>=0.0) else ( cmath.log(z1) - logswitch*2*cmath.pi*1j if (z1.imag > 0.0) else cmath.log(z1) + logswitch*2*cmath.pi*1j ) )')

B0F = Function(name = 'B0F',
               arguments = ('z1','z2','z3'),
               argstype = (complex, complex, complex),
               expression = '((z3-z1)/z1*cmath.log((z3-z1)/z3) if (z2.real == 0.0 and z2.imag == 0.0) else -cmath.log(z1/z3)+((z1-z3+z2+cmath.sqrt((z1-z3+z2)**2-4*z1*z2))/(2*z1))*cmath.log((((z1-z3+z2+cmath.sqrt((z1-z3+z2)**2-4*z1*z2))/(2*z1))-1.0)/((z1-z3+z2+cmath.sqrt((z1-z3+z2)**2-4*z1*z2))/(2*z1)))-cmath.log(((z1-z3+z2+cmath.sqrt((z1-z3+z2)**2-4*z1*z2))/(2*z1))-1.0)+((z1-z3+z2-cmath.sqrt((z1-z3+z2)**2-4*z1*z2))/(2*z1))*cmath.log((((z1-z3+z2-cmath.sqrt((z1-z3+z2)**2-4*z1*z2))/(2*z1))-1.0)/((z1-z3+z2-cmath.sqrt((z1-z3+z2)**2-4*z1*z2))/(2*z1)))-cmath.log(((z1-z3+z2-cmath.sqrt((z1-z3+z2)**2-4*z1*z2))/(2*z1))-1.0))')

regsqrt = Function(name = 'regsqrt',
                   arguments = ('z',),
                   expression = 'cmath.sqrt(z)')

arg = Function(name = 'arg',
                arguments = ('z',),
                expression = '(0.0 if abs(z)==0.0 else (cmath.log(z/abs(z))/1j).real)')


# New functions (trigonometric)

sec = Function(name = 'sec',
             arguments = ('z',),
             expression = '1./cmath.cos(z)')

asec = Function(name = 'asec',
             arguments = ('z',),
             expression = 'cmath.acos(1./z)')

csc = Function(name = 'csc',
             arguments = ('z',),
             expression = '1./cmath.sin(z)')

acsc = Function(name = 'acsc',
             arguments = ('z',),
             expression = 'cmath.asin(1./z)')

recms = Function(name= 'recms',
                 arguments = ('cms','z'),
                 argstype = (bool, complex),
                 expression = '(z if cms else z.real)')

crecms = Function(name= 'crecms',
                 arguments = ('cms','z'),
                 argstype = (bool, complex),
                 expression = '(z.conjugate() if cms else z.real)')


# Overwriting of original definition of reglog for the CMS
reglog = Function(name = 'reglog',
                arguments = ('z'),
                expression = '(0.0 if z.imag==0.0 and z.real==0.0 else ( cmath.log(z) - 2*math.pi*1j if (z.real < 0.0 and z.imag > 0.0) else cmath.log(z) ) )')
